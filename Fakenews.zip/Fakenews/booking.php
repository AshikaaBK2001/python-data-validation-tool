<?php

session_start();

require_once 'include/config.php';

if (empty($_SESSION['isLogin'])) {

    echo "<script>alert('Kindly login to proceed');location.href='index.php'</script>";
}

require_once 'include/header.php';

?>
<style>
    .container-fluid.contact_us_bg_img {
        position: relative;
    }
    .overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5); /* Adjust the opacity as needed */
        z-index: 1;
    }
    .headding {
        position: relative;
        z-index: 2;
    }
</style>
<?php

    if (isset($_POST['add_submit'])) {

        $catid = addslashes(trim($_POST['catid']));
        $newsid = addslashes(trim($_POST['newsid']));
        $quantity = addslashes(trim($_POST['quantity']));
        $address = addslashes(trim($_POST['address']));
        $date = addslashes(trim($_POST['date']));
        $phone = addslashes(trim($_POST['phone']));

        
        $insertQuery = "INSERT INTO booking (category, newspaper, quantity, from_date, address, phone) VALUES ('$catid', '$newsid', '$quantity', 
        '$date', '$address', '$phone')";

        if (mysqli_query($conn, $insertQuery)) {

            echo "<script>alert('Booking done successfully');location.href='booking.php'</script>";
        } else {
            echo "<script>alert('Unable to process your request!');location.href='booking.php'</script>";
        }
            
    }




?>
<div class="container-fluid contact_us_bg_img">
    <div class="overlay"></div> <!-- Semi-transparent black overlay -->
    <div class="container headding">
        <div class="row">
            <a href="home.php" class="fh5co_con_123"><i class="fa fa-home"></i></a>
            <a href="#" class="fh5co_con pt-2"> Booking </a>
        </div>
    </div>
</div>
<div class="container-fluid mb-4">
    <div class="container">
        <div class="col-12 text-center contact_margin_svnit ">
            <div class="text-center fh5co_heading py-2">Booking</div>
        </div>
        <form method="POST"  class="row">
            
            <div class="col-xl-4 mb-3">
                <label class="form-label">Category<span class="text-danger">*</span></label>
                <select class="form-control" name="catid" id="catid" onChange="updatePrice()">
                    <option value="">Select Category</option>
                    <?php
                    $qry = "SELECT * FROM category_master";
                    $resul = mysqli_query($conn, $qry);

                    if ($resul) {
                        while ($row_cat = mysqli_fetch_assoc($resul)) {
                            $catid = $row_cat['Category_Master_ID'];
                            $category = $row_cat['Category_name'];
                            echo "<option value='$category'>$category</option>";
                        }
                    }
                    ?>
                </select>
            </div>    
        <div class="col-xl-4 mb-3">
                <label class="form-label">Newspaper<span class="text-danger">*</span></label>
                <select class="form-control" name="newsid" id="newsid" onChange="updatePrice()">
                    <option value="">Select newspaper</option>
                    <?php
                    $qry = "SELECT * FROM newspaper_master";
                    $resul = mysqli_query($conn, $qry);

                    if ($resul) {
                        while ($row_cat = mysqli_fetch_assoc($resul)) {
                            $newsid = $row_cat['Newspaper_Master_ID'];
                            $newspaper = $row_cat['Newspaper_name'];
                            echo "<option value='$newspaper'>$newspaper</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            <div class="col-xl-4 mb-3">
                <label class="form-label">Quantity<span class="text-danger">*</span></label>
                <input autocomplete='off' type="number" class="form-control" maxlength="100" required name="quantity" >
            </div>
            
            
            <div class="col-xl-4 mb-3">
                <label class="form-label">From date<span class="text-danger">*</span></label>
                <input autocomplete='off' type="date" class="form-control" maxlength="100" required name="date">
            </div>
            <div class="col-xl-4 mb-3">
                <label class="form-label">Address<span class="text-danger">*</span></label>
                <input autocomplete='off' type="address" class="form-control" maxlength="100" required name="address">
            </div>
            <div class="col-xl-4 mb-3">
                <label class="form-label">Phone<span class="text-danger">*</span></label>
                <input autocomplete='off' type="tel" class="form-control" maxlength="100" required name="phone">
            </div>
            
            <div class="col-xl-12">
                <button type="submit" name="add_submit" class="btn btn-primary">Add</button>
            </div>
            
        </form>
        
    </div>
</div>





<?php

require_once 'include/footer.php';

?>