<?php

session_start();

require_once 'include/config.php';

if (empty($_SESSION['isLogin'])) {

    echo "<script>alert('Kindly login to proceed');location.href='index.php'</script>";
}

require_once 'include/header.php';

?>
<style>
    .container-fluid.contact_us_bg_img {
        position: relative;
    }
    .overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5); /* Adjust the opacity as needed */
        z-index: 1;
    }
    .headding {
        position: relative;
        z-index: 2;
    }
</style>
<div class="container-fluid contact_us_bg_img">
    <div class="overlay"></div> <!-- Semi-transparent black overlay -->
    <div class="container headding">
        <div class="row">
            <a href="home.php" class="fh5co_con_123"><i class="fa fa-home"></i></a>
            <a href="#" class="fh5co_con pt-2"> Bookings </a>
        </div>
    </div>
</div>
<div class="container-fluid mb-4">
    <div class="container">
        <div class="col-12 text-center contact_margin_svnit ">
            <div class="text-center fh5co_heading py-2">View bookings</div>
        </div>
        <div class="row">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Category</th>
                        <th scope="col">Newspaper</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">From date</th>
                        <th scope="col">Address</th>
                        <th scope="col">Phone</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT * FROM booking";
                    $res = mysqli_query($conn,$sql);

                    if(mysqli_num_rows($res) > 0) {
                        $i = 1;

                        while($row = mysqli_fetch_array($res)) {
                            echo "<tr>";
                            echo "<td>$i</td>";
                            echo "<td>$row[category]</td>";
                            echo "<td>$row[newspaper]</td>";
                            echo "<td>$row[quantity]</td>";
                            echo "<td>$row[from_date]</td>";
                            echo "<td>$row[address]</td>";
                            echo "<td>$row[phone]</td>";
                            echo "</tr>";
                            $i++;
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php

require_once 'include/footer.php';

?>