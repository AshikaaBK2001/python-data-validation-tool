<?php
require_once 'include/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $newsid = $_POST['newsid'];
    $day = $_POST['day'];

    // $newsid = 21;
    // $day = "Monday";
$sql = "SELECT Price from newspaper_setting WHERE 
Newspaper_Master_ID = '$newsid' AND Day = '$day'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        $data = mysqli_fetch_assoc($result);
        
        echo json_encode((int)$data['Price']);
    }
}

mysqli_close($conn);

?>