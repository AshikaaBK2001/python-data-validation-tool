<!DOCTYPE html>
<!--
	24 News by FreeHTML5.co
	Twitter: https://twitter.com/fh5co
	Facebook: https://fb.com/fh5co
	URL: https://freehtml5.co
-->
<html lang="en" class="no-js">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Fake News</title>
    <link href="css/media_query.css" rel="stylesheet" type="text/css"/>
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"
          integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link href="css/animate.css" rel="stylesheet" type="text/css"/>
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet" type="text/css"/>
    <link href="css/owl.theme.default.css" rel="stylesheet" type="text/css"/>
    <!-- Bootstrap CSS -->
    <link href="css/style_1.css" rel="stylesheet" type="text/css"/>
    <!-- Modernizr JS -->
    <script src="js/modernizr-3.5.0.min.js"></script>
</head>
<body>
<div class="container-fluid fh5co_header_bg">
    <div class="container">
        <div class="row">
            <div class="col-12 fh5co_mediya_center"><a href="#" class="color_fff fh5co_mediya_setting"><i
                    class="fa fa-clock-o"></i>&nbsp;&nbsp;&nbsp;<?php echo date('D d-m-Y'); ?></a>
                <div class="d-inline-block fh5co_trading_posotion_relative"><a href="#" class="treding_btn">Trending</a>
                    <div class="fh5co_treding_position_absolute"></div>
                </div>
                <a href="#" class="color_fff fh5co_mediya_setting">Lorem ipsum, dolor sit amet consectetur adipisicing elit.</a>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-3 fh5co_padding_menu">
                <h3><strong>Fake<span style="color: #f5bc04;">News</span></strong></h3>
            </div>
            <div class="col-12 col-md-9 align-self-center fh5co_mediya_right">
                <div class="text-center d-inline-block">
                    <a class="fh5co_display_table"><div class="fh5co_verticle_middle"><i class="fa fa-search"></i></div></a>
                </div>
                <div class="text-center d-inline-block">
                    <a class="fh5co_display_table"><div class="fh5co_verticle_middle"><i class="fa fa-linkedin"></i></div></a>
                </div>
                <div class="text-center d-inline-block">
                    <a class="fh5co_display_table"><div class="fh5co_verticle_middle"><i class="fa fa-google-plus"></i></div></a>
                </div>
                <div class="text-center d-inline-block">
                    <a href="#" target="_blank" class="fh5co_display_table"><div class="fh5co_verticle_middle"><i class="fa fa-twitter"></i></div></a>
                </div>
                <div class="text-center d-inline-block">
                    <a href="#" target="_blank" class="fh5co_display_table"><div class="fh5co_verticle_middle"><i class="fa fa-facebook"></i></div></a>
                </div>
                <!--<div class="d-inline-block text-center"><img src="images/country.png" alt="img" class="fh5co_country_width"/></div>-->
                
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid bg-faded fh5co_padd_mediya padding_786">
    <div class="container padding_786">
        <nav class="navbar navbar-toggleable-md navbar-light ">
            <button class="navbar-toggler navbar-toggler-right mt-3" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation"><span class="fa fa-bars"></span></button>
            <a class="navbar-brand" href="#"><img src="images/logo.png" alt="img" class="mobile_logo_width"/></a>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <?php
                    if($_SESSION['type']== 'Staff') {
                        $current_page = basename($_SERVER['PHP_SELF']);
                    ?>
                    <li class="nav-item <?php if ($current_page == 'home.php') echo 'active'; ?>">
                        <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    
                    <li class="nav-item <?php if ($current_page == 'daily-sales.php') echo 'active'; ?>">
                        <a class="nav-link" href="daily-sales.php">Daily sales <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item <?php if ($current_page == 'view-bookings.php') echo 'active'; ?>">
                        <a class="nav-link" href="view-bookings.php">View booking <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item <?php if ($current_page == 'daily-report.php') echo 'active'; ?>">
                        <a class="nav-link" href="daily-report.php">Daily report <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item <?php if ($current_page == 'change-password.php') echo 'active'; ?>">
                        <a class="nav-link" href="change-password.php">Change password <span class="sr-only">(current)</span></a>
                    </li>
                    
                    <li class="nav-item ">
                        <a class="nav-link" href="include/logout.php">Logout <span class="sr-only">(current)</span></a>
                    </li>
                    <?php
                    } else{
                        ?>
                        <li class="nav-item <?php if ($current_page == 'home.php') echo 'active'; ?>">
                        <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item <?php if ($current_page == 'home.php') echo 'active'; ?>">
                        <a class="nav-link" href="booking.php">Booking <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item <?php if ($current_page == 'change-password.php') echo 'active'; ?>">
                        <a class="nav-link" href="change-password.php">Change password <span class="sr-only">(current)</span></a>
                    </li>
                     <li class="nav-item ">
                        <a class="nav-link" href="http://127.0.0.1:5001" target="_blank">Fake News Detection<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="include/logout.php">Logout <span class="sr-only">(current)</span></a>
                    </li>
                        <?php
                    }
                    ?>
                </ul>
            </div>
        </nav>
    </div>
</div>