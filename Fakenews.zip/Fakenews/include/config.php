<?php
$server="localhost";
$username="root";
$password="";
$database="newspaper";
$conn = mysqli_connect($server,$username,$password,$database);
?>