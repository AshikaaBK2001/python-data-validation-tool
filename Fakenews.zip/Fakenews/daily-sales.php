<?php

session_start();

require_once 'include/config.php';

if (empty($_SESSION['isLogin'])) {

    echo "<script>alert('Kindly login to proceed');location.href='index.php'</script>";
}

require_once 'include/header.php';

?>
<style>
    .container-fluid.contact_us_bg_img {
        position: relative;
    }
    .overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5); /* Adjust the opacity as needed */
        z-index: 1;
    }
    .headding {
        position: relative;
        z-index: 2;
    }
</style>
<?php

if (isset($_POST['add_submit'])) {

    $date = date('Y-m-d');
    $totalgrossamt = addslashes(trim($_POST['totalgrossamt']));

    $insertQuery = "INSERT INTO sales_account (sales_invoice_number, date, gross_total) VALUES 
        ('$_SESSION[sales_no]', '$date', '$totalgrossamt')";

        if (mysqli_query($conn, $insertQuery)) {

            foreach ($_SESSION['sales_items'] as $item) {
                $newsid = $item['newsid'];
                $quantity = $item['quantity'];
                $price = $item['price'];
                $weight = $item['weight'];
                $custid = $item['custid'];
                $total = $item['price'] * $item['quantity'];
                $day = $item['day'];
                $date2 = $item['date'];
                
    
                $insertQuery2 = "INSERT INTO daily_sales (Sales_invoice_number, Newspaper_Master_id, Customer_id, Day, Price, Weight, Qty, Date, Total) 
                VALUES ('$_SESSION[sales_no]', '$newsid', '$custid', '$day', '$price', '$weight', '$quantity', 
                '$date2', '$total')";
    
                if (!mysqli_query($conn, $insertQuery2)) {
                    echo "<script>alert('Unable to insert details!');</script>";
                }
            }
            unset($_SESSION['sales_items']);
            unset($_SESSION['sales_no']);

            echo "<script>alert('Sales added successfully');location.href='daily-sales.php'</script>";
        } else {
            echo "<script>alert('Unable to process your request!');location.href='daily-sales.php'</script>";
        }
        
}



if(isset($_POST['add_table'])) {

    $salesno = $_POST['salesno'];
    $weight = $_POST['weight'];
    $date = $_POST['date'];
    $day = $_POST['day'];
    $custid = $_POST['custid'];
    $newsid = $_POST['newsid'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    
        
    $sales_item = array(
        'weight' => $weight,
        'date' => $date,
        'day' => $day,
        'custid' => $custid,
        'newsid' => $newsid,
        'quantity' => $quantity,
        'price' => $price
    );
    
    $_SESSION['sales_items'][] = $sales_item;
    $_SESSION['sales_no'] = $salesno;
}

if(isset($_POST['clear'])) {

    unset($_SESSION['sales_items']);
    unset($_SESSION['sales_no']);
}

?>
<div class="container-fluid contact_us_bg_img">
    <div class="overlay"></div> <!-- Semi-transparent black overlay -->
    <div class="container headding">
        <div class="row">
            <a href="home.php" class="fh5co_con_123"><i class="fa fa-home"></i></a>
            <a href="#" class="fh5co_con pt-2"> Daily sales </a>
        </div>
    </div>
</div>
<div class="container-fluid mb-4">
    <div class="container">
        <div class="col-12 text-center contact_margin_svnit ">
            <div class="text-center fh5co_heading py-2">Daily sales</div>
        </div>
        <form method="POST"  class="row">
            <div class="col-xl-4 mb-3">
                <label class="form-label">Sales invoice no<span class="text-danger">*</span></label>
                <input autocomplete='off' type="text" class="form-control" value="<?php 
                if(!empty($_SESSION['sales_no']))
                {
                    echo $_SESSION['sales_no'];
                }
                else {
                    echo 'SAL-' . rand(1000, 9999);
                }
                 ?>" required name="salesno" readonly>
            </div>
            <div class="col-xl-4 mb-3">
                <label class="form-label">Newspaper<span class="text-danger">*</span></label>
                <select class="form-control" name="newsid" id="newsid" onChange="updatePrice()">
                    <option value="">Select newspaper</option>
                    <?php
                    $qry = "SELECT * FROM newspaper_master";
                    $resul = mysqli_query($conn, $qry);

                    if ($resul) {
                        while ($row_cat = mysqli_fetch_assoc($resul)) {
                            $newsid = $row_cat['Newspaper_Master_ID'];
                            $newspaper = $row_cat['Newspaper_name'];
                            echo "<option value='$newsid'>$newspaper</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            <div class="col-xl-4 mb-3">
                <label class="form-label">Day<span class="text-danger">*</span></label>
                <select class="form-control" name="day" id="day" onChange="updatePrice()">
                    <option value="">Select day</option>
                    <option value="Monday">Monday</option>
                    <option value="Tuesday">Tuesday</option>
                    <option value="Wednesday">Wednesday</option>
                    <option value="Thursday">Thursday</option>
                    <option value="Friday">Friday</option>
                    <option value="Saturday">Saturday</option>
                    <option value="Sunday">Sunday</option>
                </select>
            </div>
            
            <div class="col-xl-4 mb-3">
                <label class="form-label">Price<span class="text-danger">*</span></label>
                <input autocomplete='off' type="number" class="form-control" maxlength="100" required name="price" id="priceDisplay" readonly>
            </div>
            <div class="col-xl-4 mb-3">
                <label class="form-label">Weight<span class="text-danger">*</span></label>
                <input autocomplete='off' type="number" class="form-control" maxlength="100" required name="weight">
            </div>
            <div class="col-xl-4 mb-3">
                <label class="form-label">Customer name<span class="text-danger">*</span></label>
                <select class="form-control" name="custid">
                    <option value="">Select customer</option>
                    <?php
                    $qry = "SELECT * FROM customer_detail";
                    $resul = mysqli_query($conn, $qry);

                    if ($resul) {
                        while ($row_cat = mysqli_fetch_assoc($resul)) {
                            $custid = $row_cat['customer_id'];
                            $customer = $row_cat['customer_name'];
                            echo "<option value='$custid'>$customer</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            <div class="col-xl-4 mb-3">
                <label class="form-label">Quantity<span class="text-danger">*</span></label>
                <input autocomplete='off' type="number" class="form-control" maxlength="100" required name="quantity" >
            </div>
            <div class="col-xl-4 mb-3">
                <label class="form-label">Date<span class="text-danger">*</span></label>
                <input autocomplete='off' type="date" class="form-control" maxlength="100" required name="date" >
            </div>
            <div class="col-xl-12">
                <button type="submit" name="add_table" class="btn btn-primary">Add</button>
            </div>
            
        </form>
        <form method="post" class="row mt-4">
            <?php
            if(isset($_SESSION['sales_items']) && !empty($_SESSION['sales_items'])) {
                $index = 1;
                $totalGrossAmount = 0; 
                ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Weight</th>
                            <th>Date</th>
                            <th>Day</th>
                            <th>Customer ID</th>
                            <th>News ID</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Gross Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    foreach($_SESSION['sales_items'] as $item) {
                        $grossAmount = $item['price'] * $item['quantity'];
                        $totalGrossAmount += $grossAmount;
                        
                        echo '<tr>';
                        echo "<td>" . $index . "</td>";
                        echo '<td>' . $item['weight'] . '</td>';
                        echo '<td>' . $item['date'] . '</td>';
                        echo '<td>' . $item['day'] . '</td>';
                        echo '<td>' . $item['custid'] . '</td>';
                        echo '<td>' . $item['newsid'] . '</td>';
                        echo '<td>' . $item['quantity'] . '</td>';
                        echo '<td>' . $item['price'] . '</td>';
                        echo '<td>' . $grossAmount . '</td>'; 
                        echo '</tr>';
                        $index++;
                    }
                    ?>
                    </tbody>
                </table>
                <div class="col-xl-4 mb-3">
                    <label class="form-label">Total Gross amount<span class="text-danger">*</span></label>
                    <input autocomplete='off' type="number" class="form-control" required name="totalgrossamt" value="<?php echo $totalGrossAmount; ?>" readonly id="totalGrossAmt">
                </div>
                
                <div class="col-xl-12">
                    <button type="submit" name="add_submit" class="btn btn-success">Save</button>
                    <button name="clear" class="btn btn-danger">Clear</button>
                </div>
                <?php
            }
            ?>
        </form>
    </div>
</div>

<script>
    function updatePrice(){
        var day = document.getElementById('day').value;
        var newsid = document.getElementById('newsid').value;

        $.ajax({
            url: 'get-price.php', 
            method: 'POST', 
            data: { day: day, newsid: newsid }, 
            success: function(response){
                document.getElementById('priceDisplay').value = response;
            },
            error: function(xhr, status, error){
                console.error(error);
            }
        });
    }
</script>



<?php

require_once 'include/footer.php';

?>