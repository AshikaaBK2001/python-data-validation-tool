<?php
session_start();

require_once 'include/config.php';
date_default_timezone_set('Asia/Kolkata');
?>
<!DOCTYPE html>
<!--
	24 News by FreeHTML5.co
	Twitter: https://twitter.com/fh5co
	Facebook: https://fb.com/fh5co
	URL: https://freehtml5.co
-->
<html lang="en" class="no-js">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Registration</title>
    <link href="css/media_query.css" rel="stylesheet" type="text/css"/>
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"
          integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link href="css/animate.css" rel="stylesheet" type="text/css"/>
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet" type="text/css"/>
    <link href="css/owl.theme.default.css" rel="stylesheet" type="text/css"/>
    <!-- Bootstrap CSS -->
    <link href="css/style_1.css" rel="stylesheet" type="text/css"/>
    <!-- Modernizr JS -->
    <script src="js/modernizr-3.5.0.min.js"></script>
    <style>
        .container-fluid.mb-4 {
            padding-top: 50px; /* Adjust vertical padding as needed */
        }

        .contact-card {
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        
    </style>
</head>
<body>
    <?php
    if (isset($_POST['register'])) {

        $username = addslashes(trim($_POST['username']));
        $usertype = "Customer";
        $phone = addslashes(trim($_POST['phone']));
        $password = addslashes(trim($_POST['password']));
        $email = addslashes(trim($_POST['email']));
        
        $insertQuery = "INSERT INTO registration (username, password, email, usertype, phone) VALUES ('$username', '$password', '$email', '$usertype', 
        '$phone')";

        if (mysqli_query($conn, $insertQuery)) {

            echo "<script>alert('User added successfully');location.href='index.php'</script>";
        } else {
            echo "<script>alert('Unable to process your request!');location.href='register.php'</script>";
        }
        
    }
    ?>

    <div class="container-fluid mb-4">
        <div class="container">
            <div class="row justify-content-center align-items-center vh-100">
                <div class="col-md-6 animate__animated animate__fadeInUp">
                    <div class="contact-card">
                        <div class="text-center fh5co_heading py-2">Registration</div>
                        <form class="row" method="POST">
                            <div class="col-12 py-3">
                                <input type="text" name="username" class="form-control fh5co_contact_text_box" placeholder="Enter Your Name">
                            </div>
                            <div class="col-12 py-3">
                                <input type="email" name="email" class="form-control fh5co_contact_text_box" placeholder="Enter Your Email">
                            </div>
                        
                            <div class="col-12 py-3">
                                <input type="tel" name="phone" class="form-control fh5co_contact_text_box" placeholder="Contact Number">
                            </div>
                            <div class="col-12 py-3">
                                <input type="password" name="password" class="form-control fh5co_contact_text_box" placeholder="Password">
                            </div>
                            
                            <div class="col-12 py-3">
                                <p class="text-center">If you are already registered, <a href="index.php">click here to login</a>.</p>
                            </div>
                            <div class="col-12 py-3 text-center">
                                <button type="submit" name="register" class="btn btn-primary contact_btn">Register</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"
        integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb"
        crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"
        integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn"
        crossorigin="anonymous"></script>
<!-- Waypoints -->
<script src="js/jquery.waypoints.min.js"></script>
<!-- Main -->
<script src="js/main.js"></script>

</body>
