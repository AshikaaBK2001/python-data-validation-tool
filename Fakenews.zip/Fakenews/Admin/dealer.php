<?php

session_start();

require_once '../include/config.php';

if (empty($_SESSION['isLogin'])) {

    echo "<script>alert('Kindly login to proceed');location.href='index.php'</script>";
}

require_once 'include/header.php';
require_once 'include/sidebar.php'

?>
<?php
    if (isset($_POST['add_submit'])) {

        $name = addslashes(trim($_POST['name']));
        $address = addslashes(trim($_POST['address']));
        $phone = addslashes(trim($_POST['phone']));
        $phone2 = addslashes(trim($_POST['phone2']));
        $email = addslashes(trim($_POST['email']));
        $amount = addslashes(trim($_POST['amount']));
        $date = date('Y-m-d');
        
        $insertQuery = "INSERT INTO dealer_detail (Dealer_name, Address, Phone, Email, Contact_person, 
        Advance_amount, date) VALUES ('$name', '$address', '$phone', '$email', '$phone2', '$amount', '$date')";

        if (mysqli_query($conn, $insertQuery)) {

            echo "<script>alert('Dealer added successfully');location.href='dealer.php'</script>";
        } else {
            echo "<script>alert('Unable to process your request!');location.href='dealer.php'</script>";
        }
        
    }

    if (isset($_POST['update'])) {

        $id = addslashes(trim($_POST['id']));
        $name = addslashes(trim($_POST['name']));
        $address = addslashes(trim($_POST['address']));
        $phone = addslashes(trim($_POST['phone']));
        $phone2 = addslashes(trim($_POST['phone2']));
        $email = addslashes(trim($_POST['email']));
        $amount = addslashes(trim($_POST['amount']));
       
        $update = "UPDATE dealer_detail SET 
        Dealer_name = '$name',
        Address = '$address',
        Phone = '$phone',
        Email = '$email',
        Contact_person = '$phone2',
        Advance_amount = '$amount'
        WHERE Dealer_ID = '$id'";

        if (mysqli_query($conn, $update)) {

            echo "<script>alert('Dealer  updated successfully');location.href='dealer.php'</script>";
        } else {
            echo "<script>alert('Unable to process your request!');location.href='dealer.php'</script>";
        }
        
    }

    if (isset($_POST['delete_submit'])) {


        if (mysqli_query($conn, "DELETE from dealer_detail WHERE Dealer_ID  = '$_POST[delete_id]'")) {

            echo "<script>alert('Dealer deleted successfully');location.href='dealer.php'</script>";
        } else {

            echo "<script>alert('Unable to process your request!');location.href='dealer.php'</script>";
        }
    }
?>

    <div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Dealer master</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="home.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Dealer master</li>
								</ol>
							</nav>
						</div>
						
					</div>
				</div>
				<!-- basic table  Start -->
				<div class="pd-20 card-box mb-30">
					<div class="clearfix mb-20">
						<div class="pull-left">
							<h4 class="text-blue h4">Dealer</h4>
						</div>
						<div class="pull-right">
							<button class="btn btn-success btn-sm scroll-click" data-toggle="modal" data-target="#add"><i class="bi bi-plus-square-fill me-2"></i> Add dealer</button>
						</div>
					</div>
					<table class="table">
						<thead>
							<tr>
								<th scope="col">#</th>
								<th scope="col">Dealer name</th>
                                <th scope="col">Address</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Email</th>
                                <th scope="col">Contact person</th>
                                <th scope="col">Advance amount</th>
								<th scope="col">Action</th>
							</tr>
						</thead>
						<tbody>
                            <?php
                            $sql = "SELECT * FROM dealer_detail";
                            $res = mysqli_query($conn,$sql);

                            if(mysqli_num_rows($res) > 0) {
                                $i = 1;

                                while($row = mysqli_fetch_array($res)) {
                                    echo "<tr>";
                                    echo "<td>$i</td>";
                                    echo "<td>$row[Dealer_name]</td>";
                                    echo "<td>$row[Address]</td>";
                                    echo "<td>$row[Phone]</td>";
                                    echo "<td>$row[Email]</td>";
                                    echo "<td>$row[Contact_person]</td>";
                                    echo "<td>$row[Advance_amount]</td>";
                                    echo "<td width=140px;>";
                                    echo "<form method='post'>";
                                    echo "<input autocomplete='off'  type='hidden' name='delete_id' value='$row[Dealer_ID]'/>
                                    <button type='submit' name='delete_submit' onClick='return confirm(" . '"Are you sure you want to delete?"' . ")' class='btn btn-danger shadow btn-xs sharp'><i class='bi bi-trash'></i></button>";
                                    echo " <button type='button' data-toggle='modal' data-target='#update$row[Dealer_ID]' class='btn btn-primary shadow btn-xs sharp'><i class='bi bi-pencil-square'></i></button>";
                                    echo "</form>";
                                    echo "</td>";
                                    echo "</tr>";
                                    $i++;
                                    ?>

                                    <div class="modal fade" id="update<?php echo $row["Dealer_ID"]; ?>" tabindex="-1" aria-labelledby="addLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <form method="POST">
                                                <div class="modal-content" style="width: 500px;">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="addLabel">Update dealer</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-xl-6 mb-3">
                                                                <label class="form-label">Dealer name<span class="text-danger">*</span></label>
                                                                <input autocomplete='off' type="text" class="form-control" maxlength="100" value="<?php echo $row['Dealer_name']; ?>" required name="name">
                                                            </div>
                                                            <div class="col-xl-6 mb-3">
                                                                <label class="form-label">Address<span class="text-danger">*</span></label>
                                                                <input autocomplete='off' type="address" class="form-control" maxlength="100" value="<?php echo $row['Address']; ?>" required name="address">
                                                            </div>
                                                            <div class="col-xl-6 mb-3">
                                                                <label class="form-label">Phone<span class="text-danger">*</span></label>
                                                                <input autocomplete='off' type="tel" class="form-control" value="<?php echo $row['Phone']; ?>" required name="phone">
                                                            </div>
                                                            <div class="col-xl-6 mb-3">
                                                                <label class="form-label">Email<span class="text-danger">*</span></label>
                                                                <input autocomplete='off' type="email" class="form-control" value="<?php echo $row['Email']; ?>" required name="email">
                                                            </div>
                                                            <div class="col-xl-6 mb-3">
                                                                <label class="form-label">Contact person<span class="text-danger">*</span></label>
                                                                <input autocomplete='off' type="tel" class="form-control" value="<?php echo $row['Contact_person']; ?>" required name="phone2">
                                                            </div>
                                                            <div class="col-xl-6 mb-3">
                                                                <label class="form-label">Advance amount<span class="text-danger">*</span></label>
                                                                <input autocomplete='off' type="number" class="form-control" value="<?php echo $row['Advance_amount']; ?>" required name="amount">
                                                            </div>
                                                            
                                                            <input autocomplete='off'  type="hidden" name="id" value="<?php echo $row['Dealer_ID']; ?>" />
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                                                        <button type="submit" name="update" class="btn btn-primary">Submit</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <?php
                                }
                            }
                            ?>
                        </tbody>
					</table>
                    <div class="modal fade" id="add" tabindex="-1" aria-labelledby="addLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <form method="POST">
                                <div class="modal-content" style="width: 500px;">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="addLabel">Add Customer</h1>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-xl-6 mb-3">
                                                <label class="form-label">Dealer name<span class="text-danger">*</span></label>
                                                <input autocomplete='off' type="text" class="form-control" maxlength="100" required name="name">
                                            </div>
                                            <div class="col-xl-6 mb-3">
                                                <label class="form-label">Address<span class="text-danger">*</span></label>
                                                <input autocomplete='off' type="address" class="form-control" maxlength="100" required name="address">
                                            </div>
                                            <div class="col-xl-6 mb-3">
                                                <label class="form-label">Phone<span class="text-danger">*</span></label>
                                                <input autocomplete='off' type="tel" class="form-control" required name="phone">
                                            </div>
                                            <div class="col-xl-6 mb-3">
                                                <label class="form-label">Email<span class="text-danger">*</span></label>
                                                <input autocomplete='off' type="email" class="form-control" required name="email">
                                            </div>
                                            <div class="col-xl-6 mb-3">
                                                <label class="form-label">Contact person<span class="text-danger">*</span></label>
                                                <input autocomplete='off' type="tel" class="form-control" required name="phone2">
                                            </div>
                                            <div class="col-xl-6 mb-3">
                                                <label class="form-label">Advance amount<span class="text-danger">*</span></label>
                                                <input autocomplete='off' type="number" class="form-control" required name="amount">
                                            </div>
                                            
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                                        <button type="submit" name="add_submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
				</div>				
			</div>
			<div class="footer-wrap pd-20 mb-20 card-box">
				FakeNews - Admin <a href="home.php" >Home</a>
			</div>
		</div>
	</div>


<?php

require_once 'include/footer.php';

?>