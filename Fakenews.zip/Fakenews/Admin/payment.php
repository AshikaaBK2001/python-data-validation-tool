<?php

session_start();

require_once '../include/config.php';

if (empty($_SESSION['isLogin'])) {

    echo "<script>alert('Kindly login to proceed');location.href='index.php'</script>";
}

require_once 'include/header.php';
require_once 'include/sidebar.php'

?>
<?php
if (isset($_POST['update_payment'])) {

    $amounttopay = $_POST['amounttopay'];
    $paid = $_POST['amountPaid'] + $amounttopay;
    $balance = $_POST['pendingAmount'] - $amounttopay;
    $purchaseno = $_POST['purchaseno'];
    
    $update = "UPDATE purchase_account_detail SET Paid = '$paid' ,Pending = '$balance' WHERE Purchase_no = '$purchaseno'";

    if (mysqli_query($conn, $update)) {

        echo "<script>alert('Payment done successfully');location.href='payment.php'</script>";
    } else {
        echo "<script>alert('Unable to process your request!');location.href='payment.php'</script>";
    }
    
}
   
  
?>

    <div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Payment</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="home.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Payment</li>
								</ol>
							</nav>
						</div>
						
					</div>
				</div>
				<!-- basic table  Start -->
				<div class="pd-20 card-box mb-30">
					<div class="clearfix mb-20">
						<div class="pull-left">
							<h4 class="text-blue h4">Payment</h4>
						</div>
						<!-- <div class="pull-right">
							<button class="btn btn-success btn-sm scroll-click" data-toggle="modal" data-target="#add"><i class="bi bi-plus-square-fill me-2"></i> Add settings</button>
						</div> -->
					</div>
					<form method="post" class="row g-3">
                        <div class="col-xl-4 mb-3">
                            <label class="form-label">Purchase no<span class="text-danger">*</span></label>
                            <select class="form-control" name="purchaseno" id="purchaseno">
                                <option value="">Select No</option>
                                <?php
                                $qry = "SELECT * FROM purchase_account_detail";
                                $resul = mysqli_query($conn, $qry);

                                if ($resul) {
                                    while ($row_cat = mysqli_fetch_assoc($resul)) {
                                        $purchaseno = $row_cat['Purchase_no'];
                                        echo "<option value='$purchaseno'>$purchaseno</option>";
                                    }
                                }
                                ?>
                            </select>
                        </div>

                        <div class="col-xl-8">
                            <div class="row g-3">
                                <div class="col-xl-6 mb-3">
                                    <label class="form-label">Dealer Name<span class="text-danger">*</span></label>
                                    <input autocomplete='off' type="text" class="form-control" maxlength="100" required name="dealerName" id="dealerName" readonly>
                                </div>
                                <div class="col-xl-6 mb-3">
                                    <label class="form-label">Total amount<span class="text-danger">*</span></label>
                                    <input autocomplete='off' type="text" class="form-control" maxlength="100" required name="totalAmount" id="totalAmount" readonly>
                                </div>
                                <div class="col-xl-6 mb-3">
                                    <label class="form-label">Amount paid<span class="text-danger">*</span></label>
                                    <input autocomplete='off' type="text" class="form-control" maxlength="100" required name="amountPaid" id="amountPaid" readonly>
                                </div>
                                <div class="col-xl-6 mb-3">
                                    <label class="form-label">Pending amount<span class="text-danger">*</span></label>
                                    <input autocomplete='off' type="text" class="form-control" maxlength="100" required name="pendingAmount" id="pendingAmount" readonly>
                                </div>
                                <div class="col-xl-6 mb-3">
                                    <label class="form-label">Amount to pay<span class="text-danger">*</span></label>
                                    <input autocomplete='off' type="number" class="form-control" maxlength="100" required name="amounttopay" >
                                </div>
                                <div class="col-xl-12">
                                    <button type="submit" name="update_payment" class="btn btn-success">Pay now</button>
                                </div>
                            </div>
                        </div>
                    </form>
				</div>				
			</div>
			<div class="footer-wrap pd-20 mb-20 card-box">
				FakeNews - Admin <a href="home.php" >Home</a>
			</div>
		</div>
	</div>
    <script>
    document.getElementById('purchaseno').addEventListener('change', function() {
        var purchaseNo = this.value; // Get the selected purchase number

        // Make an AJAX request to fetch details based on the selected purchase number
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    // Parse the JSON response
                    var data = JSON.parse(xhr.responseText);

                    // Update the input fields with the fetched details
                    document.getElementById('dealerName').value = data.Dealer_name;
                    document.getElementById('totalAmount').value = data.Gross_Total;
                    document.getElementById('amountPaid').value = data.Paid;
                    document.getElementById('pendingAmount').value = data.Pending;
                } else {
                    console.error('Request failed: ' + xhr.status);
                }
            }
        };
        xhr.open('POST', 'get-purchase.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.send('purchase_no=' + purchaseNo);
    });
</script>
<?php

require_once 'include/footer.php';

?>