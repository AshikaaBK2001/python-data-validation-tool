<div class="left-side-bar">
		<div class="brand-logo">
			<a href="index.html">
				<img src="vendors/images/deskapp-logo.svg" alt="" class="dark-logo">
				<img src="vendors/images/deskapp-logo-white.svg" alt="" class="light-logo">
			</a>
			<div class="close-sidebar" data-toggle="left-sidebar-close">
				<i class="ion-close-round"></i>
			</div>
		</div>
		<div class="menu-block customscroll">
			<div class="sidebar-menu">
				<ul id="accordion-menu">
					<li>
						<a href="home.php" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-house-1"></span><span class="mtext">Home</span>
						</a>
						
					</li>
					<li class="dropdown">
						<a href="javascript:;" class="dropdown-toggle">
							<span class="micon dw dw-edit2"></span><span class="mtext">Master</span>
						</a>
						<ul class="submenu">
							<li><a href="category.php">Category</a></li>
							<li><a href="language.php">Language</a></li>
                            <li><a href="customer.php">Customer</a></li>
							<li><a href="dealer.php">Dealer</a></li>
                            <li><a href="newspaper.php">Newspaper</a></li>
						</ul>
					</li>
                    <li>
						<a href="newspaper-settings.php" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-calendar1"></span><span class="mtext">Newspaper settings</span>
						</a>
					</li>
                    <li>
						<a href="purchase.php" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-calendar1"></span><span class="mtext">Purchase</span>
						</a>
					</li>
                    <li>
						<a href="payment.php" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-calendar1"></span><span class="mtext">Payment</span>
						</a>
					</li>
                    <li>
						<a href="dealer-report.php" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-calendar1"></span><span class="mtext">Report</span>
						</a>
					</li>
                    <li>
						<a href="view-stocks.php" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-calendar1"></span><span class="mtext">View stocks</span>
						</a>
					</li>
                    <li>
						<a href="register.php" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-calendar1"></span><span class="mtext">Register</span>
						</a>
					</li>
                    <li>
						<a href="include/logout.php" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-calendar1"></span><span class="mtext">Logout</span>
						</a>
					</li>
					
				</ul>
			</div>
		</div>
	</div>