<?php

session_start();

require_once '../include/config.php';

if (empty($_SESSION['isLogin'])) {

    echo "<script>alert('Kindly login to proceed');location.href='index.php'</script>";
}

require_once 'include/header.php';
require_once 'include/sidebar.php'

?>
<?php
    if (isset($_POST['add_submit'])) {

        $totalgrossamt = addslashes(trim($_POST['totalgrossamt']));
        $paidamount = addslashes(trim($_POST['paidamount']));
        $balance = addslashes(trim($_POST['balance']));
        $date = date('Y-m-d');
        
        $insertQuery = "INSERT INTO purchase_account_detail (Purchase_no, Dealer_id, Date, Gross_Total, Paid, Pending) VALUES 
        ('$_SESSION[purchase_no]', '$_SESSION[dealerid]', '$date', '$totalgrossamt', '$paidamount', '$balance')";

        if (mysqli_query($conn, $insertQuery)) {

            foreach ($_SESSION['added_items'] as $item) {
                $newsid = $item['newsid'];
                $quantity = $item['quantity'];
                $price = $item['price'];
                $weight = $item['weight'];
                $total = $item['price'] * $item['quantity'];
                $day = $item['day'];
                $date2 = $item['date'];
                
    
                $insertQuery2 = "INSERT INTO purchase_detail (Purchase_no, Dealer_ID, Newspaper_Master_ID, Date, Qty, 
                weight, price, total, day) VALUES ('$_SESSION[purchase_no]', '$_SESSION[dealerid]', '$newsid', 
                '$date2', '$quantity', '$weight', '$price', '$total', '$day')";
    
                if (!mysqli_query($conn, $insertQuery2)) {
                    echo "<script>alert('Unable to insert medicine details!');</script>";
                }
            }
            unset($_SESSION['added_items']);
            unset($_SESSION['purchase_no']);
            unset($_SESSION['dealerid']);

            echo "<script>alert('Purchase done successfully');location.href='purchase.php'</script>";
        } else {
            echo "<script>alert('Unable to process your request!');location.href='purchase.php'</script>";
        }
        
    }

    if(isset($_POST['add_table'])) {

        $purchaseno = $_POST['purchaseno'];
        $weight = $_POST['weight'];
        $date = $_POST['date'];
        $day = $_POST['day'];
        $dealerid = $_POST['dealerid'];
        $newsid = $_POST['newsid'];
        $quantity = $_POST['quantity'];
        $price = $_POST['price'];
        
            
        $added_item = array(
            'weight' => $weight,
            'date' => $date,
            'day' => $day,
            'dealerid' => $dealerid,
            'newsid' => $newsid,
            'quantity' => $quantity,
            'price' => $price
        );
        
        $_SESSION['added_items'][] = $added_item;
        $_SESSION['purchase_no'] = $purchaseno;
        $_SESSION['dealerid'] = $dealerid;
    }
    
    if(isset($_POST['clear'])) {
    
        unset($_SESSION['added_items']);
        unset($_SESSION['purchase_no']);
        unset($_SESSION['dealerid']);
    }

  
?>

    <div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Purchase</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="home.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Purchase</li>
								</ol>
							</nav>
						</div>
						
					</div>
				</div>
				<!-- basic table  Start -->
				<div class="pd-20 card-box mb-30">
					<div class="clearfix mb-20">
						<div class="pull-left">
							<h4 class="text-blue h4">Purchase</h4>
						</div>
						<!-- <div class="pull-right">
							<button class="btn btn-success btn-sm scroll-click" data-toggle="modal" data-target="#add"><i class="bi bi-plus-square-fill me-2"></i> Add settings</button>
						</div> -->
					</div>
					<form method="post" class="row">
                        <div class="col-xl-4 mb-3">
                            <label class="form-label">Purchase no<span class="text-danger">*</span></label>
                            <input autocomplete='off' value="<?php 
                            if(!empty($_SESSION['purchase_no']))
                            {
                                echo $_SESSION['purchase_no'];
                            }
                            else {
                                echo 'PUR-' . rand(1000, 9999);
                            }
                             ?>" class="form-control" required name="purchaseno" readonly>
                        </div>
                        <div class="col-xl-4 mb-3">
                            <label class="form-label">Dealer<span class="text-danger">*</span></label>
                            <?php
                            if(empty($_SESSION['dealerid'])) {
                                ?>
                            <select class="form-control" name="dealerid">
                                <option value="">Select dealer</option>
                                <?php
                                $qry = "SELECT * FROM dealer_detail";
                                $resul = mysqli_query($conn, $qry);

                                if ($resul) {
                                    while ($row_cat = mysqli_fetch_assoc($resul)) {
                                        $dealerid = $row_cat['Dealer_ID'];
                                        $dealer = $row_cat['Dealer_name'];
                                        echo "<option value='$dealerid'>$dealer</option>";
                                    }
                                }
                                ?>
                            </select>
                            <?php
                            } else 
                            {?>
                            <input autocomplete='off' class="form-control"  value="<?php echo $_SESSION['dealerid']; ?>"name="dealerid" readonly>
                            <?php } ?>


                        </div>
                        <div class="col-xl-4 mb-3">
                            <label class="form-label">Newspaper<span class="text-danger">*</span></label>
                            <select class="form-control" name="newsid">
                                <option value="">Select Newspaper</option>
                                <?php
                                $qry = "SELECT * FROM newspaper_master";
                                $resul = mysqli_query($conn, $qry);

                                if ($resul) {
                                    while ($row_cat = mysqli_fetch_assoc($resul)) {
                                        $newsid = $row_cat['Newspaper_Master_ID'];
                                        $newspaper = $row_cat['Newspaper_name'];
                                        echo "<option value='$newsid'>$newspaper</option>";
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <!-- <div class="col-xl-4 mb-3">
                            <label class="form-label">Language<span class="text-danger">*</span></label>
                            <select class="form-control" name="langid">
                                <option value="">Select language</option>
                                <?php
                                $qry = "SELECT * FROM language_master";
                                $resul = mysqli_query($conn, $qry);

                                if ($resul) {
                                    while ($row_cat = mysqli_fetch_assoc($resul)) {
                                        $langid = $row_cat['Language_ID'];
                                        $language = $row_cat['Language'];
                                        echo "<option value='$langid'>$language</option>";
                                    }
                                }
                                ?>
                            </select>
                        </div> -->
                        <div class="col-xl-4 mb-3">
                            <label class="form-label">Weight<span class="text-danger">*</span></label>
                            <input autocomplete='off' type="number" class="form-control" maxlength="100" required name="weight">
                        </div>
                        <div class="col-xl-4 mb-3">
                            <label class="form-label">Date<span class="text-danger">*</span></label>
                            <input autocomplete='off' type="date" class="form-control" maxlength="100" required name="date" id="dateInput">
                        </div>
                        <div class="col-xl-4 mb-3">
                            <label class="form-label">Day<span class="text-danger">*</span></label>
                            <input autocomplete='off' type="text" class="form-control" maxlength="100" required name="day" id="dayInput" readonly>
                        </div>
                        <div class="col-xl-4 mb-3">
                            <label class="form-label">Price<span class="text-danger">*</span></label>
                            <input autocomplete='off' type="number" class="form-control" maxlength="100" required name="price">
                        </div>
                        <div class="col-xl-4 mb-3">
                            <label class="form-label">Quantity<span class="text-danger">*</span></label>
                            <input autocomplete='off' type="number" class="form-control" maxlength="100" required name="quantity">
                        </div>
                        <div class="col-xl-12">
                            <button type="submit" name="add_table" class="btn btn-success">Add</button>
                        </div>
                    </form>
                    <form method="post" class="row mt-4">
                        <?php
                        if(isset($_SESSION['added_items']) && !empty($_SESSION['added_items'])) {
                            $index = 1;
                            $totalGrossAmount = 0; 
                            ?>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Weight</th>
                                        <th>Date</th>
                                        <th>Day</th>
                                        <th>Dealer ID</th>
                                        <th>News ID</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Gross Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                foreach($_SESSION['added_items'] as $item) {
                                    $grossAmount = $item['price'] * $item['quantity'];
                                    $totalGrossAmount += $grossAmount;
                                    
                                    echo '<tr>';
                                    echo "<td>" . $index . "</td>";
                                    echo '<td>' . $item['weight'] . '</td>';
                                    echo '<td>' . $item['date'] . '</td>';
                                    echo '<td>' . $item['day'] . '</td>';
                                    echo '<td>' . $item['dealerid'] . '</td>';
                                    echo '<td>' . $item['newsid'] . '</td>';
                                    echo '<td>' . $item['quantity'] . '</td>';
                                    echo '<td>' . $item['price'] . '</td>';
                                    echo '<td>' . $grossAmount . '</td>'; 
                                    echo '</tr>';
                                    $index++;
                                }
                                ?>
                                </tbody>
                            </table>
                            <div class="col-xl-4 mb-3">
                                <label class="form-label">Total Gross amount<span class="text-danger">*</span></label>
                                <input autocomplete='off' type="number" class="form-control" required name="totalgrossamt" value="<?php echo $totalGrossAmount; ?>" readonly id="totalGrossAmt">
                            </div>
                            <div class="col-xl-4 mb-3">
                                <label class="form-label">Paid amount<span class="text-danger">*</span></label>
                                <input autocomplete='off' type="number" class="form-control" required name="paidamount" id="paidAmount" value="0">
                            </div>
                            <div class="col-xl-4 mb-3">
                                <label class="form-label">Balance<span class="text-danger">*</span></label>
                                <input autocomplete='off' type="number" class="form-control" required name="balance" readonly id="balance" value="<?php echo $totalGrossAmount; ?>">
                            </div>
                            <div class="col-xl-12">
                                <button type="submit" name="add_submit" class="btn btn-success">Save</button>
                                <button name="clear" class="btn btn-danger">Clear</button>
                            </div>
                            <?php
                        }
                        ?>
                    </form>

                    
				</div>				
			</div>
			<div class="footer-wrap pd-20 mb-20 card-box">
				FakeNews - Admin <a href="home.php" >Home</a>
			</div>
		</div>
	</div>
<script>
    document.getElementById('dateInput').addEventListener('change', function() {
        var selectedDate = new Date(this.value);
        var options = { weekday: 'long' };
        var day = new Intl.DateTimeFormat('en-US', options).format(selectedDate);
        document.getElementById('dayInput').value = day;
    });
</script>

<script>
    var totalGrossAmtInput = document.getElementById('totalGrossAmt');
    var paidAmountInput = document.getElementById('paidAmount');
    var balanceInput = document.getElementById('balance');
    
    paidAmountInput.addEventListener('input', function() {
        var totalGrossAmt = parseFloat(totalGrossAmtInput.value);
        var paidAmount = parseFloat(paidAmountInput.value);
        
        var balance = totalGrossAmt - paidAmount;
        
        balanceInput.value = balance.toFixed(2); 
    });
</script>

<?php

require_once 'include/footer.php';

?>