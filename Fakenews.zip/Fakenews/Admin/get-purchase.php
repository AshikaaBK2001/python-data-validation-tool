<?php
require_once '../include/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $puchaseno = $_POST['purchase_no'];

    $result = mysqli_query($conn, "SELECT p.Dealer_id, p.Date, 
        p.Gross_Total, p.Paid, p.Pending , d.Dealer_name
        FROM purchase_account_detail p, dealer_detail d WHERE d.Dealer_ID  = p.Dealer_id AND Purchase_no = '$puchaseno'");

    if ($result) {
        $data = mysqli_fetch_assoc($result);
        header('Content-Type: application/json');
        echo json_encode($data);
    } else {
        echo json_encode(array('error' => 'Failed to fetch details'));
    }
}

mysqli_close($conn);

?>