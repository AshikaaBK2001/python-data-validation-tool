<?php

session_start();

require_once '../include/config.php';

if (empty($_SESSION['isLogin'])) {

    echo "<script>alert('Kindly login to proceed');location.href='index.php'</script>";
}

require_once 'include/header.php';
require_once 'include/sidebar.php'

?>
<?php
   
?>

    <div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Stocks</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="home.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Stocks</li>
								</ol>
							</nav>
						</div>
						
					</div>
				</div>
				<!-- basic table  Start -->
				<div class="pd-20 card-box mb-30">
					<div class="clearfix mb-20">
						<div class="pull-left">
							<h4 class="text-blue h4">Stocks</h4>
						</div>
						<div class="pull-right">
							<!-- <button class="btn btn-success btn-sm scroll-click" data-toggle="modal" data-target="#add"><i class="bi bi-plus-square-fill me-2"></i> Add dealer</button> -->
						</div>
					</div>
					<table class="table">
						<thead>
							<tr>
								<th scope="col">#</th>
								<th scope="col">Newspaper</th>
                                <th scope="col">Quantity name</th>
                                <th scope="col">Language name</th>
							</tr>
						</thead>
						<tbody>
                            <?php
                            $sql = "SELECT * FROM stock";
                            $res = mysqli_query($conn,$sql);

                            if(mysqli_num_rows($res) > 0) {
                                $i = 1;

                                while($row = mysqli_fetch_array($res)) {
                                    echo "<tr>";
                                    echo "<td>$i</td>";
                                    echo "<td>$row[newspaper_id]</td>";
                                    echo "<td>$row[quantity]</td>";
                                    echo "<td>$row[language_name]</td>";
                                    echo "</tr>";
                                    $i++;
                                    
                                }
                            }
                            ?>
                        </tbody>
					</table>
                    
				</div>				
			</div>
			<div class="footer-wrap pd-20 mb-20 card-box">
				FakeNews - Admin <a href="home.php" >Home</a>
			</div>
		</div>
	</div>


<?php

require_once 'include/footer.php';

?>