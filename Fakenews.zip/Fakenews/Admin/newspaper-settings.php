<?php

session_start();

require_once '../include/config.php';

if (empty($_SESSION['isLogin'])) {

    echo "<script>alert('Kindly login to proceed');location.href='index.php'</script>";
}

require_once 'include/header.php';
require_once 'include/sidebar.php'

?>
<?php
    if (isset($_POST['add_submit'])) {

        $price = addslashes(trim($_POST['price']));
        $newsid = addslashes(trim($_POST['newsid']));
        $day = addslashes(trim($_POST['day']));
        
        $insertQuery = "INSERT INTO newspaper_setting (Newspaper_Master_ID, Day, Price) VALUES 
        ('$newsid', '$day', '$price')";

        if (mysqli_query($conn, $insertQuery)) {

            echo "<script>alert('settings added successfully');location.href='newspaper-settings.php'</script>";
        } else {
            echo "<script>alert('Unable to process your request!');location.href='newspaper-settings.php'</script>";
        }
        
    }

    if (isset($_POST['update'])) {

        $id = addslashes(trim($_POST['id']));
        $price = addslashes(trim($_POST['price']));
        $newsid = addslashes(trim($_POST['newsid']));
        $day = addslashes(trim($_POST['day']));
       
        $update = "UPDATE newspaper_setting SET Newspaper_Master_ID = '$newsid',Day = '$day',
        Price = '$price' WHERE Newspaper_settings_ID = '$id'";

        if (mysqli_query($conn, $update)) {

            echo "<script>alert('Settings updated successfully');location.href='newspaper-settings.php'</script>";
        } else {
            echo "<script>alert('Unable to process your request!');location.href='newspaper-settings.php'</script>";
        }
        
    }

    if (isset($_POST['delete_submit'])) {


        if (mysqli_query($conn, "DELETE from newspaper_setting WHERE Newspaper_settings_ID  = '$_POST[delete_id]'")) {

            echo "<script>alert('Settings deleted successfully');location.href='newspaper-settings.php'</script>";
        } else {

            echo "<script>alert('Unable to process your request!');location.href='newspaper-settings.php'</script>";
        }
    }
?>

    <div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Newspaper Settings</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="home.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Newspaper Settings</li>
								</ol>
							</nav>
						</div>
						
					</div>
				</div>
				<!-- basic table  Start -->
				<div class="pd-20 card-box mb-30">
					<div class="clearfix mb-20">
						<div class="pull-left">
							<h4 class="text-blue h4">Newspaper setting</h4>
						</div>
						<div class="pull-right">
							<button class="btn btn-success btn-sm scroll-click" data-toggle="modal" data-target="#add"><i class="bi bi-plus-square-fill me-2"></i> Add settings</button>
						</div>
					</div>
					<table class="table">
						<thead>
							<tr>
								<th scope="col">#</th>
								<th scope="col">Newspaper name</th>
                                <th scope="col">Day</th>
                                <th scope="col">Price</th>
								<th scope="col">Action</th>
							</tr>
						</thead>
						<tbody>
                            <?php
                            $sql = "SELECT n.Newspaper_settings_ID, n.Newspaper_Master_ID, n.Day, 
                            n.Price, nm.Newspaper_name 
                            FROM newspaper_setting n 
                            INNER JOIN newspaper_master nm ON n.Newspaper_Master_ID = nm.Newspaper_Master_ID";
            
                            $res = mysqli_query($conn,$sql);

                            if(mysqli_num_rows($res) > 0) {
                                $i = 1;

                                while($row = mysqli_fetch_array($res)) {
                                    echo "<tr>";
                                    echo "<td>$i</td>";
                                    echo "<td>$row[Newspaper_name]</td>";
                                    echo "<td>$row[Day]</td>";
                                    echo "<td>$row[Price]</td>";
                                    echo "<td width=140px;>";
                                    echo "<form method='post'>";
                                    echo "<input autocomplete='off'  type='hidden' name='delete_id' value='$row[Newspaper_settings_ID]'/>
                                    <button type='submit' name='delete_submit' onClick='return confirm(" . '"Are you sure you want to delete?"' . ")' class='btn btn-danger shadow btn-xs sharp'><i class='bi bi-trash'></i></button>";
                                    echo " <button type='button' data-toggle='modal' data-target='#update$row[Newspaper_settings_ID]' class='btn btn-primary shadow btn-xs sharp'><i class='bi bi-pencil-square'></i></button>";
                                    echo "</form>";
                                    echo "</td>";
                                    echo "</tr>";
                                    $i++;
                                    ?>

                                    <div class="modal fade" id="update<?php echo $row["Newspaper_settings_ID"]; ?>" tabindex="-1" aria-labelledby="addLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <form method="POST">
                                                <div class="modal-content" style="width: 500px;">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="addLabel">Update Settings</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-xl-6 mb-3">
                                                                <label class="form-label">Newspaper<span class="text-danger">*</span></label>
                                                                <select class="form-control" name="newsid">
                                                                    <option value="">Select Newspaper</option>
                                                                    <?php
                                                                    $qry = "SELECT * FROM newspaper_master";
                                                                    $resul = mysqli_query($conn, $qry);

                                                                    if ($resul) {
                                                                        while ($row_cat = mysqli_fetch_assoc($resul)) {
                                                                            $newsid = $row_cat['Newspaper_Master_ID'];
                                                                            $newspaper = $row_cat['Newspaper_name'];
                                                                            $selected = ($newsid == $row['Newspaper_Master_ID']) ? 'selected' : '';
                                                                            echo "<option value='$newsid' $selected>$newspaper</option>";
                                                                        }
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                            <div class="col-xl-6 mb-3">
                                                                <label class="form-label">Day<span class="text-danger">*</span></label>
                                                                <select class="form-control" name="day">
                                                                    <option value="">Select day</option>
                                                                    <option value="Monday" <?php if ($row['Day'] == "Monday") echo "selected"; ?>>Monday</option>
                                                                    <option value="Tuesday" <?php if ($row['Day'] == "Tuesday") echo "selected"; ?>>Tuesday</option>
                                                                    <option value="Wednesday" <?php if ($row['Day'] == "Wednesday") echo "selected"; ?>>Wednesday</option>
                                                                    <option value="Thursday" <?php if ($row['Day'] == "Thursday") echo "selected"; ?>>Thursday</option>
                                                                    <option value="Friday" <?php if ($row['Day'] == "Friday") echo "selected"; ?>>Friday</option>
                                                                    <option value="Saturday" <?php if ($row['Day'] == "Saturday") echo "selected"; ?>>Saturday</option>
                                                                    <option value="Sunday" <?php if ($row['Day'] == "Sunday") echo "selected"; ?>>Sunday</option>
                                                                </select>
                                                            </div>

                                                            <div class="col-xl-6 mb-3">
                                                                <label class="form-label">Price<span class="text-danger">*</span></label>
                                                                <input autocomplete='off' type="number" class="form-control" maxlength="100" value="<?php echo $row['Price']; ?>" required name="price">
                                                            </div>
                                                            <input autocomplete='off'  type="hidden" name="id" value="<?php echo $row['Newspaper_settings_ID']; ?>" />
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                                                        <button type="submit" name="update" class="btn btn-primary">Submit</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <?php
                                }
                            }
                            ?>
                        </tbody>
					</table>
                    <div class="modal fade" id="add" tabindex="-1" aria-labelledby="addLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <form method="POST">
                                <div class="modal-content" style="width: 500px;">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="addLabel">Add Customer</h1>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-xl-6 mb-3">
                                                <label class="form-label">Newspaper<span class="text-danger">*</span></label>
                                                <select class="form-control" name="newsid">
                                                    <option value="">Select Newspaper</option>
                                                    <?php
                                                    $qry = "SELECT * FROM newspaper_master";
                                                    $resul = mysqli_query($conn, $qry);

                                                    if ($resul) {
                                                        while ($row_cat = mysqli_fetch_assoc($resul)) {
                                                            $newsid = $row_cat['Newspaper_Master_ID'];
                                                            $newspaper = $row_cat['Newspaper_name'];
                                                            echo "<option value='$newsid'>$newspaper</option>";
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="col-xl-6 mb-3">
                                                <label class="form-label">Day<span class="text-danger">*</span></label>
                                                <select class="form-control" name="day">
                                                    <option value="">Select day</option>
                                                    <option value="Monday">Monday</option>
                                                    <option value="Tuesday">Tuesday</option>
                                                    <option value="Wednesday">Wednesday</option>
                                                    <option value="Thursday">Thursday</option>
                                                    <option value="Friday">Friday</option>
                                                    <option value="Saturday">Saturday</option>
                                                    <option value="Sunday">Sunday</option>
                                                </select>
                                            </div>

                                            <div class="col-xl-6 mb-3">
                                                <label class="form-label">Price<span class="text-danger">*</span></label>
                                                <input autocomplete='off' type="number" class="form-control" maxlength="100" required name="price">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                                        <button type="submit" name="add_submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
				</div>				
			</div>
			<div class="footer-wrap pd-20 mb-20 card-box">
				FakeNews - Admin <a href="home.php" >Home</a>
			</div>
		</div>
	</div>


<?php

require_once 'include/footer.php';

?>