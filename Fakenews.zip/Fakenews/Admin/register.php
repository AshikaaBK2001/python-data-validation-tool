<?php

session_start();

require_once '../include/config.php';

if (empty($_SESSION['isLogin'])) {

    echo "<script>alert('Kindly login to proceed');location.href='index.php'</script>";
}

require_once 'include/header.php';
require_once 'include/sidebar.php'

?>
<?php
    if (isset($_POST['add_submit'])) {

        $username = addslashes(trim($_POST['username']));
        $usertype = addslashes(trim($_POST['usertype']));
        $phone = addslashes(trim($_POST['phone']));
        $password = addslashes(trim($_POST['password']));
        $email = addslashes(trim($_POST['email']));
        
        $insertQuery = "INSERT INTO registration (username, password, email, usertype, phone) VALUES ('$username', '$password', '$email', '$usertype', 
        '$phone')";

        if (mysqli_query($conn, $insertQuery)) {

            echo "<script>alert('User added successfully');location.href='register.php'</script>";
        } else {
            echo "<script>alert('Unable to process your request!');location.href='register.php'</script>";
        }
        
    }

    if (isset($_POST['update'])) {

        $id = addslashes(trim($_POST['id']));
        $username = addslashes(trim($_POST['username']));
        $usertype = addslashes(trim($_POST['usertype']));
        $phone = addslashes(trim($_POST['phone']));
        $password = addslashes(trim($_POST['password']));
        $email = addslashes(trim($_POST['email']));

        $update = "UPDATE registration SET 
        username = '$username',
        password = '$password',
        email = '$email',
        usertype = '$usertype',
        phone = '$phone'
        WHERE user_id = '$id'";

        if (mysqli_query($conn, $update)) {

            echo "<script>alert('User updated successfully');location.href='register.php'</script>";
        } else {
            echo "<script>alert('Unable to process your request!');location.href='register.php'</script>";
        }
        
    }

    if (isset($_POST['delete_submit'])) {


        if (mysqli_query($conn, "DELETE from registration WHERE user_id  = '$_POST[delete_id]'")) {

            echo "<script>alert('User deleted successfully');location.href='register.php'</script>";
        } else {

            echo "<script>alert('Unable to process your request!');location.href='register.php'</script>";
        }
    }
?>

    <div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Register</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="home.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Register</li>
								</ol>
							</nav>
						</div>
						
					</div>
				</div>
				<!-- basic table  Start -->
				<div class="pd-20 card-box mb-30">
					<div class="clearfix mb-20">
						<div class="pull-left">
							<h4 class="text-blue h4">Register</h4>
						</div>
						<div class="pull-right">
							<button class="btn btn-success btn-sm scroll-click" data-toggle="modal" data-target="#add"><i class="bi bi-plus-square-fill me-2"></i> Add users</button>
						</div>
					</div>
					<table class="table">
						<thead>
							<tr>
								<th scope="col">#</th>
								<th scope="col">User name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Usertype</th>
                                <th scope="col">Password</th>
								<th scope="col">Action</th>
							</tr>
						</thead>
						<tbody>
                            <?php
                            $sql = "SELECT * FROM registration";
                            $res = mysqli_query($conn,$sql);

                            if(mysqli_num_rows($res) > 0) {
                                $i = 1;

                                while($row = mysqli_fetch_array($res)) {
                                    echo "<tr>";
                                    echo "<td>$i</td>";
                                    echo "<td>$row[username]</td>";
                                    echo "<td>$row[email]</td>";
                                    echo "<td>$row[phone]</td>";
                                    echo "<td>$row[usertype]</td>";
                                    echo "<td>$row[password]</td>";
                                    echo "<td width=140px;>";
                                    echo "<form method='post'>";
                                    echo "<input autocomplete='off'  type='hidden' name='delete_id' value='$row[user_id]'/>
                                    <button type='submit' name='delete_submit' onClick='return confirm(" . '"Are you sure you want to delete?"' . ")' class='btn btn-danger shadow btn-xs sharp'><i class='bi bi-trash'></i></button>";
                                    echo " <button type='button' data-toggle='modal' data-target='#update$row[user_id]' class='btn btn-primary shadow btn-xs sharp'><i class='bi bi-pencil-square'></i></button>";
                                    echo "</form>";
                                    echo "</td>";
                                    echo "</tr>";
                                    $i++;
                                    ?>

                                    <div class="modal fade" id="update<?php echo $row["user_id"]; ?>" tabindex="-1" aria-labelledby="addLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <form method="POST">
                                                <div class="modal-content" style="width: 500px;">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="addLabel">Update user</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-xl-6 mb-3">
                                                                <label class="form-label">User name<span class="text-danger">*</span></label>
                                                                <input autocomplete='off' type="text" class="form-control" maxlength="100" value="<?php echo $row['username']; ?>" required name="username">
                                                            </div>
                                                            <div class="col-xl-6 mb-3">
                                                                <label class="form-label">Email<span class="text-danger">*</span></label>
                                                                <input autocomplete='off' type="email" class="form-control" maxlength="100" value="<?php echo $row['email']; ?>" required name="email">
                                                            </div>
                                                            <div class="col-xl-6 mb-3">
                                                                <label class="form-label">Phone<span class="text-danger">*</span></label>
                                                                <input autocomplete='off' type="tel" class="form-control" value="<?php echo $row['phone']; ?>" required name="phone">
                                                            </div>
                                                            <div class="col-xl-6 mb-3">
                                                                <label class="form-label">Usertype<span class="text-danger">*</span></label>
                                                                <select class="form-control" name="usertype">
                                                                    <option value="Staff" <?php if ($row['usertype'] == 'Staff') {
                                                                                                                echo 'selected';
                                                                                                            } ?>>Staff</option>
                                                                    <option value="Customer" <?php if ($row['usertype'] == 'Customer') {
                                                                                                                echo 'selected';
                                                                                                            } ?>>Customer</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-xl-6 mb-3">
                                                                <label class="form-label">Password<span class="text-danger">*</span></label>
                                                                <input autocomplete='off' type="password" class="form-control" value="<?php echo $row['password']; ?>" required name="password">
                                                            </div>
                                                            
                                                            <input autocomplete='off'  type="hidden" name="id" value="<?php echo $row['user_id']; ?>" />
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                                                        <button type="submit" name="update" class="btn btn-primary">Submit</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <?php
                                }
                            }
                            ?>
                        </tbody>
					</table>
                    <div class="modal fade" id="add" tabindex="-1" aria-labelledby="addLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <form method="POST">
                                <div class="modal-content" style="width: 500px;">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="addLabel">Add User</h1>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-xl-6 mb-3">
                                                <label class="form-label">User name<span class="text-danger">*</span></label>
                                                <input autocomplete='off' type="text" class="form-control" maxlength="100" required name="username">
                                            </div>
                                            <div class="col-xl-6 mb-3">
                                                <label class="form-label">Email<span class="text-danger">*</span></label>
                                                <input autocomplete='off' type="email" class="form-control" maxlength="100" required name="email">
                                            </div>
                                            <div class="col-xl-6 mb-3">
                                                <label class="form-label">Phone<span class="text-danger">*</span></label>
                                                <input autocomplete='off' type="tel" class="form-control" required name="phone">
                                            </div>
                                            <div class="col-xl-6 mb-3">
                                                <label class="form-label">Usertype<span class="text-danger">*</span></label>
                                                <select class="form-control" name="usertype">
                                                    <option value="">Select</option>
                                                    <option value="Staff">Staff</option>
                                                    <option value="Customer">Customer</option>
                                                </select>
                                            </div>
                                            <div class="col-xl-6 mb-3">
                                                <label class="form-label">Password<span class="text-danger">*</span></label>
                                                <input autocomplete='off' type="password" class="form-control" required name="password">
                                            </div>
                                            
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                                        <button type="submit" name="add_submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
				</div>				
			</div>
			<div class="footer-wrap pd-20 mb-20 card-box">
				FakeNews - Admin <a href="home.php" >Home</a>
			</div>
		</div>
	</div>


<?php

require_once 'include/footer.php';

?>