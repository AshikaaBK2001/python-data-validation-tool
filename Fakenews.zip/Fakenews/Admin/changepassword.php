<?php
require_once '../config/connection.php';

?>
<!DOCTYPE html>
<html>
<head>
	<title>Change Password</title>
<?php require_once 'include/meta.php'; ?>
</head>
<body>

	<div class="header">
		<div class="header-left">
			<div class="menu-icon dw dw-menu"></div>
			<div class="search-toggle-icon dw dw-search2" data-toggle="header_search"></div>
			<div class="header-search">
				<h3>Change Password</h3>
			</div>
		</div>
		<?php require_once 'include/header.php'; ?>
	<div class="mobile-menu-overlay"></div>

	<div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Change Password</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Change Password</li>
								</ol>
							</nav>
						</div>
					</div>
				</div>
			<div class="pd-20 card-box mb-30">
				<div class="clearfix">
					<div class="pull-left">
						<h4 class="text-blue h4">Change Password</h4><br>
					</div>
				</div>
				<form action="" method="POST">
					<div class="form-group row">
						<label class="col-sm-12 col-md-2 col-form-label">Current Password</label>
						<div class="col-sm-12 col-md-10">
							<input class="form-control" type="password" placeholder="Enter Current Password">
						</div>
					</div>

					<div class="form-group row">
						<label class="col-sm-12 col-md-2 col-form-label">New Password</label>
						<div class="col-sm-12 col-md-10">
							<input class="form-control" type="password" placeholder="Enter New Password">
						</div>
					</div>

					<div class="form-group row">
						<label class="col-sm-12 col-md-2 col-form-label">Confirm New Password</label>
						<div class="col-sm-12 col-md-10">
							<input class="form-control" type="password" placeholder="Confirm New Password">
						</div>
					</div>

					<div class="form-group row">
						<div class="col-sm-12 col-md-2"></div>
						<div class="col-sm-12 col-md-10">
							<button type="submit" name="" class="btn btn-primary">Change Password</button>
							<button type="reset" class="btn btn-danger">Clear</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	<?php require_once 'include/footer.php'; ?>
</body>
</html>