<?php

session_start();

require_once '../include/config.php';

if (empty($_SESSION['isLogin'])) {

    echo "<script>alert('Kindly login to proceed');location.href='index.php'</script>";
}

require_once 'include/header.php';
require_once 'include/sidebar.php'

?>
<?php
if (empty($_GET['f_text'])) {

    $f_text = "";
} else {

    $f_text = $_GET['f_text'];
}

if (isset($_GET['f_search'])) {

    if (!empty($f_text)) {


        $sql = "SELECT * from purchase_detail where Dealer_ID = '$f_text'";
    }
}
   
  
?>

    <div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Report</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="home.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Report</li>
								</ol>
							</nav>
						</div>
						
					</div>
				</div>
				<!-- basic table  Start -->
				<div class="pd-20 card-box mb-30">
					<div class="clearfix mb-20">
						<div class="pull-left">
							<h4 class="text-blue h4">Dealers report</h4>
						</div>
                        <div class="pull-right">
                            <form class="input-group">
                                <select class="form-control" name="f_text">
                                    <option value="">Select dealer</option>
                                    <?php
                                    $qry = "SELECT * FROM dealer_detail";
                                    $resul = mysqli_query($conn, $qry);

                                    if ($resul) {
                                        while ($row_cat = mysqli_fetch_assoc($resul)) {
                                            $dealerid = $row_cat['Dealer_ID'];
                                            $dealer = $row_cat['Dealer_name'];
                                            echo "<option value='$dealerid'>$dealer</option>";
                                        }
                                    }
                                    ?>
                                </select>                                
                                <span class="input-group-btn ml-2">
                                    <button class="btn btn-primary" name="f_search">Search</button>
                                    <a class="btn btn-danger ml-1" href="dealer-report.php">Clear</a>
                                    <a class="btn btn-success ml-1" href="print-dealer-report.php?f_text=<?php echo $f_text;?>">Print</a>
                                </span>
                            </form>
                        </div>
                        <?php
                        if (!empty($_GET['f_text'])) {
                        ?>

                        <table class="table">
						<thead>
							<tr>
								<th scope="col">#</th>
								<th scope="col">Purchase no</th>
                                <th scope="col">Newspaper</th>
                                <th scope="col">Day</th>
								<th scope="col">Date</th>
                                <th scope="col">Price</th>
                                <th scope="col">Quantity</th>
                                <th scope="col">Total</th>
							</tr>
						</thead>
						<tbody>
                            <?php
                            
            
                            $res = mysqli_query($conn,$sql);

                            if(mysqli_num_rows($res) > 0) {
                                $i = 1;

                                while($row = mysqli_fetch_array($res)) {
                                    echo "<tr>";
                                    echo "<td>$i</td>";
                                    echo "<td>$row[Purchase_no]</td>";
                                    echo "<td>$row[Newspaper_Master_ID]</td>";
                                    echo "<td>$row[day]</td>";
                                    echo "<td>$row[Date]</td>";
                                    echo "<td>$row[price]</td>";
                                    echo "<td>$row[Qty]</td>";
                                    echo "<td>$row[total]</td>";
                                    echo "</tr>";
                                    $i++;
                                }
                            }
                            ?>
                        </tbody>
					</table>
                    <?php
                    }
                    ?>

					</div>
					
				</div>				
			</div>
			<div class="footer-wrap pd-20 mb-20 card-box">
				FakeNews - Admin <a href="home.php" >Home</a>
			</div>
		</div>
	</div>
    
<?php

require_once 'include/footer.php';

?>