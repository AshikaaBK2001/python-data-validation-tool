<?php
require_once '../include/config.php';
require_once '../libs/fpdf.php';

$filename = "Dealer report" . date('Y-m-d') . ".pdf";

$f_text = isset($_GET['f_text']) ? $_GET['f_text'] : '';

$sql = "SELECT * from purchase_detail where Dealer_ID = '$f_text'";

mysqli_set_charset($conn, "utf8");
$user_query = mysqli_query($conn, $sql);

$pdf = new FPDF();

$pdf->AddPage();

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Dealer report', 0, 1, 'C');

$pdf->SetFont('Arial', 'B', 8); 
$pdf->Cell(10, 10, 'ID', 1); 
$pdf->Cell(30, 10, 'Purchase no', 1); 
$pdf->Cell(30, 10, 'Newspaper', 1); 
$pdf->Cell(20, 10, 'Day', 1); 
$pdf->Cell(25, 10, 'Date', 1); 
$pdf->Cell(15, 10, 'Price', 1); 
$pdf->Cell(15, 10, 'Quantity', 1); 
$pdf->Cell(15, 10, 'Total', 1); 
$pdf->Ln();

if (mysqli_num_rows($user_query) > 0) {
    $i = 1;
    while ($row = mysqli_fetch_assoc($user_query)) {
        $pdf->SetFont('Arial', '', 8); 
        $pdf->Cell(10, 10, $i, 1); 
        $pdf->Cell(30, 10, $row['Purchase_no'], 1); 
        $pdf->Cell(30, 10, $row['Newspaper_Master_ID'], 1); 
        $pdf->Cell(20, 10, $row['day'], 1); 
        $pdf->Cell(25, 10, $row['Date'], 1); 
        $pdf->Cell(15, 10, $row['price'], 1); 
        $pdf->Cell(15, 10, $row['Qty'], 1); 
        $pdf->Cell(15, 10, $row['total'], 1); 
        $pdf->Ln();
        $i++;
    }
}

$pdf->Output($filename, 'D');
?>
