<?php

session_start();

require_once '../include/config.php';

if (empty($_SESSION['isLogin'])) {

    echo "<script>alert('Kindly login to proceed');location.href='index.php'</script>";
}

require_once 'include/header.php';
require_once 'include/sidebar.php'

?>
<?php
    if (isset($_POST['add_submit'])) {

        $name = addslashes(trim($_POST['name']));
        $langid = addslashes(trim($_POST['langid']));
        $catid = addslashes(trim($_POST['catid']));
        
        $insertQuery = "INSERT INTO newspaper_master (Language_ID, Category_Master_ID, Newspaper_name) VALUES 
        ('$langid', '$catid', '$name')";

        if (mysqli_query($conn, $insertQuery)) {

            echo "<script>alert('Newspaper added successfully');location.href='newspaper.php'</script>";
        } else {
            echo "<script>alert('Unable to process your request!');location.href='newspaper.php'</script>";
        }
        
    }

    if (isset($_POST['update'])) {

        $id = addslashes(trim($_POST['id']));
        $name = addslashes(trim($_POST['name']));
        $langid = addslashes(trim($_POST['langid']));
        $catid = addslashes(trim($_POST['catid']));
       
        $update = "UPDATE newspaper_master SET Newspaper_name = '$name',Language_ID = '$langid',
        Category_Master_ID = '$catid' WHERE Newspaper_Master_ID = '$id'";

        if (mysqli_query($conn, $update)) {

            echo "<script>alert('Newspaper  updated successfully');location.href='newspaper.php'</script>";
        } else {
            echo "<script>alert('Unable to process your request!');location.href='newspaper.php'</script>";
        }
        
    }

    if (isset($_POST['delete_submit'])) {


        if (mysqli_query($conn, "DELETE from newspaper_master WHERE Newspaper_Master_ID  = '$_POST[delete_id]'")) {

            echo "<script>alert('Newspaper deleted successfully');location.href='newspaper.php'</script>";
        } else {

            echo "<script>alert('Unable to process your request!');location.href='newspaper.php'</script>";
        }
    }
?>

    <div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Newspaper master</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="home.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Newspaper master</li>
								</ol>
							</nav>
						</div>
						
					</div>
				</div>
				<!-- basic table  Start -->
				<div class="pd-20 card-box mb-30">
					<div class="clearfix mb-20">
						<div class="pull-left">
							<h4 class="text-blue h4">Newspaper</h4>
						</div>
						<div class="pull-right">
							<button class="btn btn-success btn-sm scroll-click" data-toggle="modal" data-target="#add"><i class="bi bi-plus-square-fill me-2"></i> Add newspaper</button>
						</div>
					</div>
					<table class="table">
						<thead>
							<tr>
								<th scope="col">#</th>
								<th scope="col">Newspaper name</th>
                                <th scope="col">Language</th>
                                <th scope="col">Category</th>
								<th scope="col">Action</th>
							</tr>
						</thead>
						<tbody>
                            <?php
                            $sql = "SELECT n.Newspaper_Master_ID, n.Language_ID, n.Category_Master_ID, 
                            n.Newspaper_name, l.Language, c.Category_name 
                            FROM newspaper_master n 
                            INNER JOIN category_master c ON n.Category_Master_ID = c.Category_Master_ID
                            INNER JOIN language_master l ON n.Language_ID = l.Language_ID";
            
                            $res = mysqli_query($conn,$sql);

                            if(mysqli_num_rows($res) > 0) {
                                $i = 1;

                                while($row = mysqli_fetch_array($res)) {
                                    echo "<tr>";
                                    echo "<td>$i</td>";
                                    echo "<td>$row[Newspaper_name]</td>";
                                    echo "<td>$row[Language]</td>";
                                    echo "<td>$row[Category_name]</td>";
                                    echo "<td width=140px;>";
                                    echo "<form method='post'>";
                                    echo "<input autocomplete='off'  type='hidden' name='delete_id' value='$row[Newspaper_Master_ID]'/>
                                    <button type='submit' name='delete_submit' onClick='return confirm(" . '"Are you sure you want to delete?"' . ")' class='btn btn-danger shadow btn-xs sharp'><i class='bi bi-trash'></i></button>";
                                    echo " <button type='button' data-toggle='modal' data-target='#update$row[Newspaper_Master_ID]' class='btn btn-primary shadow btn-xs sharp'><i class='bi bi-pencil-square'></i></button>";
                                    echo "</form>";
                                    echo "</td>";
                                    echo "</tr>";
                                    $i++;
                                    ?>

                                    <div class="modal fade" id="update<?php echo $row["Newspaper_Master_ID"]; ?>" tabindex="-1" aria-labelledby="addLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <form method="POST">
                                                <div class="modal-content" style="width: 500px;">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="addLabel">Update Newspaper</h1>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-xl-6 mb-3">
                                                                <label class="form-label">Newspaper name<span class="text-danger">*</span></label>
                                                                <input autocomplete='off' type="text" class="form-control" maxlength="100" value="<?php echo $row['Newspaper_name']; ?>" required name="name">
                                                            </div>
                                                            <div class="col-xl-6 mb-3">
                                                                <label class="form-label">Category<span class="text-danger">*</span></label>
                                                                <select class="form-control" name="catid">
                                                                    <option value="">Select category</option>
                                                                    <?php
                                                                    $qry = "SELECT * FROM category_master";
                                                                    $resul = mysqli_query($conn, $qry);

                                                                    if ($resul) {
                                                                        while ($row_cat = mysqli_fetch_assoc($resul)) {
                                                                            $catid = $row_cat['Category_Master_ID'];
                                                                            $category = $row_cat['Category_name'];
                                                                            $selected = ($catid == $row['Category_Master_ID']) ? 'selected' : '';
                                                                            echo "<option value='$catid' $selected>$category</option>";
                                                                        }
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                            <div class="col-xl-6 mb-3">
                                                                <label class="form-label">Language<span class="text-danger">*</span></label>
                                                                <select class="form-control" name="langid">
                                                                    <option value="">Select language</option>
                                                                    <?php
                                                                    $qry = "SELECT * FROM language_master";
                                                                    $resul = mysqli_query($conn, $qry);

                                                                    if ($resul) {
                                                                        while ($row_cat = mysqli_fetch_assoc($resul)) {
                                                                            $langid = $row_cat['Language_ID'];
                                                                            $language = $row_cat['Language'];
                                                                            $selected = ($langid == $row['Language_ID']) ? 'selected' : '';
                                                                            echo "<option value='$langid' $selected>$language</option>";
                                                                        }
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                            <input autocomplete='off'  type="hidden" name="id" value="<?php echo $row['Newspaper_Master_ID']; ?>" />
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                                                        <button type="submit" name="update" class="btn btn-primary">Submit</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <?php
                                }
                            }
                            ?>
                        </tbody>
					</table>
                    <div class="modal fade" id="add" tabindex="-1" aria-labelledby="addLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <form method="POST">
                                <div class="modal-content" style="width: 500px;">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="addLabel">Add Customer</h1>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-xl-6 mb-3">
                                                <label class="form-label">Newspaper name<span class="text-danger">*</span></label>
                                                <input autocomplete='off' type="text" class="form-control" maxlength="100" required name="name">
                                            </div>
                                            <div class="col-xl-6 mb-3">
                                                <label class="form-label">Category<span class="text-danger">*</span></label>
                                                <select class="form-control" name="catid">
                                                    <option value="">Select category</option>
                                                    <?php
                                                    $qry = "SELECT * FROM category_master";
                                                    $resul = mysqli_query($conn, $qry);

                                                    if ($resul) {
                                                        while ($row_cat = mysqli_fetch_assoc($resul)) {
                                                            $catid = $row_cat['Category_Master_ID'];
                                                            $category = $row_cat['Category_name'];
                                                            echo "<option value='$catid'>$category</option>";
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="col-xl-6 mb-3">
                                                <label class="form-label">Language<span class="text-danger">*</span></label>
                                                <select class="form-control" name="langid">
                                                    <option value="">Select language</option>
                                                    <?php
                                                    $qry = "SELECT * FROM language_master";
                                                    $resul = mysqli_query($conn, $qry);

                                                    if ($resul) {
                                                        while ($row_cat = mysqli_fetch_assoc($resul)) {
                                                            $langid = $row_cat['Language_ID'];
                                                            $language = $row_cat['Language'];
                                                            echo "<option value='$langid'>$language</option>";
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                            
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                                        <button type="submit" name="add_submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
				</div>				
			</div>
			<div class="footer-wrap pd-20 mb-20 card-box">
				FakeNews - Admin <a href="home.php" >Home</a>
			</div>
		</div>
	</div>


<?php

require_once 'include/footer.php';

?>