-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 30, 2024 at 07:02 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newspaper`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `booking_id` int(10) UNSIGNED NOT NULL,
  `category` varchar(45) DEFAULT NULL,
  `newspaper` varchar(45) DEFAULT NULL,
  `quantity` varchar(45) DEFAULT NULL,
  `from_date` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`booking_id`, `category`, `newspaper`, `quantity`, `from_date`, `address`, `phone`) VALUES
(1, 'weekly', 'deccan herald', '25', '4/5/2019', 'mangalore', '9854525255'),
(2, 'weekly', 'deccan herald', '25', '4/26/2019', 'mangalore', ''),
(3, 'weekly', 'deccan herald', '25', '4/26/2019', 'mangalore', ''),
(4, 'Monthly', 'deccan herald', '11', '2024-03-28', 'manglore', '1223232323');

-- --------------------------------------------------------

--
-- Table structure for table `category_master`
--

CREATE TABLE `category_master` (
  `Category_Master_ID` int(10) UNSIGNED NOT NULL,
  `Category_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `category_master`
--

INSERT INTO `category_master` (`Category_Master_ID`, `Category_name`) VALUES
(21, 'Monthly'),
(23, 'Daily'),
(26, 'Weekly Twice'),
(27, 'Weekly Once');

-- --------------------------------------------------------

--
-- Table structure for table `customer_detail`
--

CREATE TABLE `customer_detail` (
  `customer_id` int(10) UNSIGNED NOT NULL,
  `customer_name` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `customer_detail`
--

INSERT INTO `customer_detail` (`customer_id`, `customer_name`, `address`) VALUES
(10, 'Muralidar', 'Mangalore'),
(11, 'danu', 'mangalore'),
(12, 'manu', 'mangalore'),
(13, 'lohit', 'mangalore'),
(15, 'Kushi', 'mangalore');

-- --------------------------------------------------------

--
-- Table structure for table `daily_sales`
--

CREATE TABLE `daily_sales` (
  `Daily_sales` int(10) UNSIGNED NOT NULL,
  `Sales_invoice_number` varchar(45) DEFAULT NULL,
  `Newspaper_Master_id` varchar(45) DEFAULT NULL,
  `Customer_id` varchar(45) DEFAULT NULL,
  `Day` varchar(45) DEFAULT NULL,
  `Price` varchar(45) DEFAULT NULL,
  `Weight` varchar(45) DEFAULT NULL,
  `Qty` varchar(45) DEFAULT NULL,
  `Date` varchar(45) DEFAULT NULL,
  `Total` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `daily_sales`
--

INSERT INTO `daily_sales` (`Daily_sales`, `Sales_invoice_number`, `Newspaper_Master_id`, `Customer_id`, `Day`, `Price`, `Weight`, `Qty`, `Date`, `Total`) VALUES
(1, '100', 'Times', 'muralidar f', 'Wednesday', '8', '8', '9', '2019/04/24', '72'),
(2, '102', 'Hindu', 'muralidar', 'Friday', '10', '8', '9', '2019-03-12', '90'),
(3, '104', 'Hindu', 'danu', 'Friday', '10', '8', '9', '2019-03-12', '90'),
(4, '105', 'deccan herald', 'muralidar', 'Thursday', '6', '8', '9', '2019-04-21', '54'),
(5, '105', 'deccan herald', 'danu', 'Satarday', '10', '8', '9', '2019-04-21', '90'),
(6, '106', 'deccan herald', 'muralidar', 'Wednesday', '5', '8', '9', '2019/04/03', '45'),
(7, '107', 'deccan herald', 'muralidar', 'Monday', '4', '8', '9', '2019/04/24', '36'),
(8, '108', 'deccan herald', 'muralidar', 'Tuesday', '5', '8', '9', '2019-04-08', '45'),
(9, '109', 'deccan herald', 'manu', 'Friday', '6', '8', '50', '2019-04-24', '300'),
(10, '110', 'deccan herald', 'danu', 'Wednesday', '5', '8', '100', '2019-03-19', '500'),
(11, '111', 'deccan herald', 'danu', 'Monday', '4', '8', '9', '2019-04-02', '36'),
(12, '112', 'deccan herald', 'muralidar', 'Friday', '6', '1', '450', '2019-04-05', '2700'),
(13, '112', 'times of india', 'muralidar', 'Friday', '10', '1', '450', '2024-03-02', '4500'),
(14, 'SAL-7649', '20', '10', 'Monday', '4', '10', '10', '2024-03-25', '40'),
(16, 'SAL-9393', '20', '10', 'Wednesday', '5', '11', '23', '2024-03-26', '115'),
(19, 'SAL-4932', '21', '11', 'Tuesday', '9', '11', '22', '2024-03-25', '198'),
(20, 'SAL-1692', '22', '10', 'Monday', '9', '12', '23', '2024-03-26', '207'),
(21, 'SAL-1692', '20', '10', 'Monday', '4', '44', '123', '2024-03-26', '492'),
(22, 'SAL-2906', '20', '10', 'Monday', '4', '12', '21', '2024-03-28', '84'),
(23, 'SAL-2906', '21', '11', 'Thursday', '10', '11', '23', '2024-03-26', '230');

-- --------------------------------------------------------

--
-- Table structure for table `dealer_detail`
--

CREATE TABLE `dealer_detail` (
  `Dealer_ID` int(10) UNSIGNED NOT NULL,
  `Dealer_name` varchar(20) DEFAULT NULL,
  `Address` varchar(30) DEFAULT NULL,
  `Phone` int(10) UNSIGNED DEFAULT NULL,
  `Email` varchar(20) DEFAULT NULL,
  `Contact_person` varchar(20) DEFAULT NULL,
  `Advance_amount` varchar(45) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `dealer_detail`
--

INSERT INTO `dealer_detail` (`Dealer_ID`, `Dealer_name`, `Address`, `Phone`, `Email`, `Contact_person`, `Advance_amount`, `date`) VALUES
(1, 'anurag makki', 'chikmangalore', 97865435, 'anurag155@gmail.com', '75588696', '450', '2019-03-06'),
(2, 'samson', 'bengalore', 97865435, 'sam7882@gmail.com', '75588696', '500', '2019-03-26'),
(3, 'Rachitha', 'neermarga mangalore', 4294967295, 'rachitha@gmail.com', 'Rachitha', '2000', NULL),
(4, 'Rachitha', 'neermarga', 987654325, 'rachitha@gmail.com', '7419635235', '2000', '2024-03-18');

-- --------------------------------------------------------

--
-- Table structure for table `language_master`
--

CREATE TABLE `language_master` (
  `Language_ID` int(10) UNSIGNED NOT NULL,
  `Language` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `language_master`
--

INSERT INTO `language_master` (`Language_ID`, `Language`) VALUES
(10, 'English'),
(12, 'Hindi'),
(13, 'Tamil'),
(14, 'Kannada'),
(15, 'Marathi');

-- --------------------------------------------------------

--
-- Table structure for table `newspaper_master`
--

CREATE TABLE `newspaper_master` (
  `Newspaper_Master_ID` int(10) UNSIGNED NOT NULL,
  `Language_ID` int(10) UNSIGNED NOT NULL,
  `Category_Master_ID` int(10) UNSIGNED NOT NULL,
  `Newspaper_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `newspaper_master`
--

INSERT INTO `newspaper_master` (`Newspaper_Master_ID`, `Language_ID`, `Category_Master_ID`, `Newspaper_name`) VALUES
(20, 10, 21, 'deccan herald'),
(21, 10, 21, 'times of india'),
(22, 10, 21, 'udayavani'),
(23, 10, 21, 'vijayavani'),
(24, 12, 21, 'hindhu'),
(25, 10, 21, 'hosadiganta'),
(27, 13, 21, 'udayavani'),
(30, 14, 23, 'vijayavani'),
(34, 14, 23, 'vijayakarnataka'),
(35, 12, 23, 'hindhu'),
(38, 14, 21, 'Udayavani');

-- --------------------------------------------------------

--
-- Table structure for table `newspaper_setting`
--

CREATE TABLE `newspaper_setting` (
  `Newspaper_settings_ID` int(10) UNSIGNED NOT NULL,
  `Newspaper_Master_ID` int(10) UNSIGNED DEFAULT NULL,
  `Day` varchar(200) DEFAULT NULL,
  `Price` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `newspaper_setting`
--

INSERT INTO `newspaper_setting` (`Newspaper_settings_ID`, `Newspaper_Master_ID`, `Day`, `Price`) VALUES
(9, 20, 'Monday', 4),
(10, 20, 'Tuesday', 5),
(11, 20, 'Wednesday', 5),
(12, 20, 'Thursday', 6),
(13, 20, 'Friday', 6),
(14, 20, 'Sunday', 10),
(15, 20, 'Saturday', 10),
(16, 21, 'Monday', 10),
(18, 21, 'Tuesday', 9),
(21, 21, 'Wednesday', 10),
(22, 22, 'Monday', 9),
(23, 21, 'Thursday', 10),
(24, 21, 'Friday', 10),
(25, 29, 'Wednesday', 10),
(26, 22, 'Saturday', 10),
(27, 21, 'Saturday', 10),
(28, 37, 'Tuesday', 5),
(29, 25, 'Sunday', 5);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_account_detail`
--

CREATE TABLE `purchase_account_detail` (
  `Purchase_trans_ID` int(10) UNSIGNED NOT NULL,
  `Purchase_no` varchar(45) DEFAULT NULL,
  `Dealer_id` varchar(45) DEFAULT NULL,
  `Date` varchar(45) DEFAULT NULL,
  `Gross_Total` varchar(45) DEFAULT NULL,
  `Paid` varchar(45) DEFAULT NULL,
  `Pending` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `purchase_account_detail`
--

INSERT INTO `purchase_account_detail` (`Purchase_trans_ID`, `Purchase_no`, `Dealer_id`, `Date`, `Gross_Total`, `Paid`, `Pending`) VALUES
(6, '100', '1', '2019/03/02', '600', '200', '400'),
(7, '101', '1', '2019/03/13', '375', '275', '100'),
(8, '103', '2', '2019/03/02', '250', '100', '150'),
(9, '105', '2', '2019/03/11', '400', '100', '300'),
(10, '106', '2', '2019/03/11', '400', '300', '100'),
(11, 'PUR-4183', '1', '2024-03-23', '1500', '1000', '500.00'),
(12, 'PUR-3237', '2', '2024-03-23', '1520', '1200', '320.00'),
(13, 'PUR-2037', '3', '2024-03-23', '1080', '600', '480'),
(14, 'PUR-6392', '3', '2024-03-27', '298', '298', '0');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_detail`
--

CREATE TABLE `purchase_detail` (
  `Purchase_no` varchar(45) DEFAULT NULL,
  `Dealer_ID` varchar(45) DEFAULT NULL,
  `Newspaper_Master_ID` varchar(45) DEFAULT NULL,
  `Date` varchar(45) DEFAULT NULL,
  `Qty` varchar(45) DEFAULT NULL,
  `weight` varchar(45) DEFAULT NULL,
  `price` varchar(45) DEFAULT NULL,
  `total` varchar(45) DEFAULT NULL,
  `day` varchar(45) DEFAULT NULL,
  `purchase_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `purchase_detail`
--

INSERT INTO `purchase_detail` (`Purchase_no`, `Dealer_ID`, `Newspaper_Master_ID`, `Date`, `Qty`, `weight`, `price`, `total`, `day`, `purchase_id`) VALUES
('100', '1', '20', '2019/03/02', '100', '5', '6', '600', 'Friday', 18),
('101', '1', '20', '2019/03/13', '25', '5', '5', '125', 'Wednesday', 19),
('101', '1', '20', '2019/03/13', '25', '25', '5', '125', 'Wednesday', 20),
('101', '1', '20', '2019/03/13', '25', '5', '5', '125', 'Wednesday', 21),
('102', '2', '21', '2019/03/13', '25', '5', '10', '250', 'Wednesday', 22),
('102', '2', '21', '2019/03/13', '25', '5', '10', '250', 'Wednesday', 23),
('103', '2', '20', '2019/03/02', '25', '5', '10', '250', 'Satarday', 24),
('105', '2', '20', '2019/03/11', '100', '5', '4', '400', 'Monday', 25),
('107', '1', '21', '2019/03/13', '25', '5', '10', '250', 'Wednesday', 26),
('108', '2', '21', '2019/03/13', '100', '5', '10', '1000', 'Wednesday', 27),
('PUR-4183', '1', '$', '2024-03-23', '$', '$', '$', '$', '$', 28),
('PUR-4183', '1', '$', '2024-03-23', '$', '$', '$', '$', '$', 29),
('PUR-3237', '2', '', '2024-03-24', '160', '5', '5', '800', 'Sunday', 30),
('PUR-3237', '2', '', '2024-03-25', '120', '15', '6', '720', 'Monday', 31),
('PUR-2037', '3', '22', '2024-03-07', '100', '12', '6', '600', 'Thursday', 32),
('PUR-2037', '3', '35', '2024-03-24', '120', '30', '4', '480', 'Sunday', 33),
('PUR-6392', '3', '20', '2024-02-29', '50', '12', '5', '250', 'Thursday', 34),
('PUR-6392', '3', '22', '2024-03-21', '12', '22', '4', '48', 'Thursday', 35);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(450) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `usertype` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`user_id`, `username`, `password`, `email`, `usertype`, `phone`) VALUES
(11, 'Vishal', '12', 'admin@gmail.com', 'Admin', '8971553640'),
(12, 'yathi', '123', 'staff@gmail.com', 'Staff', '7829636340'),
(14, 'ajay', '12', 'customer@gmail.com', 'Customer', '1234567945');

-- --------------------------------------------------------

--
-- Table structure for table `sales_account`
--

CREATE TABLE `sales_account` (
  `sales_account_id` int(10) UNSIGNED NOT NULL,
  `sales_invoice_number` varchar(45) DEFAULT NULL,
  `customer_id` varchar(45) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  `gross_total` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `sales_account`
--

INSERT INTO `sales_account` (`sales_account_id`, `sales_invoice_number`, `customer_id`, `date`, `gross_total`) VALUES
(1, '104', 'danu', '2019/03/12', '9'),
(2, '105', 'danu', '2019/04/21', '18'),
(3, '109', 'manu', '2019/04/24', '50'),
(4, '110', 'danu', '2019/03/19', '100'),
(5, '111', 'danu', '2019/04/02', '9'),
(6, 'SAL-2906', NULL, '2024-03-27', '314');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `stock id` int(10) UNSIGNED NOT NULL,
  `newspaper_id` varchar(45) DEFAULT NULL,
  `quantity` varchar(45) DEFAULT NULL,
  `language_name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`stock id`, `newspaper_id`, `quantity`, `language_name`) VALUES
(2, 'deccan herald', '100', 'english'),
(3, 'deccan herald', '25', 'english'),
(4, 'deccan herald', '25', 'english'),
(5, 'deccan herald', '100', 'english'),
(6, 'deccan herald', '100', 'english');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `category_master`
--
ALTER TABLE `category_master`
  ADD PRIMARY KEY (`Category_Master_ID`);

--
-- Indexes for table `customer_detail`
--
ALTER TABLE `customer_detail`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `daily_sales`
--
ALTER TABLE `daily_sales`
  ADD PRIMARY KEY (`Daily_sales`);

--
-- Indexes for table `dealer_detail`
--
ALTER TABLE `dealer_detail`
  ADD PRIMARY KEY (`Dealer_ID`);

--
-- Indexes for table `language_master`
--
ALTER TABLE `language_master`
  ADD PRIMARY KEY (`Language_ID`);

--
-- Indexes for table `newspaper_master`
--
ALTER TABLE `newspaper_master`
  ADD PRIMARY KEY (`Newspaper_Master_ID`);

--
-- Indexes for table `newspaper_setting`
--
ALTER TABLE `newspaper_setting`
  ADD PRIMARY KEY (`Newspaper_settings_ID`);

--
-- Indexes for table `purchase_account_detail`
--
ALTER TABLE `purchase_account_detail`
  ADD PRIMARY KEY (`Purchase_trans_ID`);

--
-- Indexes for table `purchase_detail`
--
ALTER TABLE `purchase_detail`
  ADD PRIMARY KEY (`purchase_id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `sales_account`
--
ALTER TABLE `sales_account`
  ADD PRIMARY KEY (`sales_account_id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`stock id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `booking_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `category_master`
--
ALTER TABLE `category_master`
  MODIFY `Category_Master_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `customer_detail`
--
ALTER TABLE `customer_detail`
  MODIFY `customer_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `daily_sales`
--
ALTER TABLE `daily_sales`
  MODIFY `Daily_sales` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `dealer_detail`
--
ALTER TABLE `dealer_detail`
  MODIFY `Dealer_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `language_master`
--
ALTER TABLE `language_master`
  MODIFY `Language_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `newspaper_master`
--
ALTER TABLE `newspaper_master`
  MODIFY `Newspaper_Master_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `newspaper_setting`
--
ALTER TABLE `newspaper_setting`
  MODIFY `Newspaper_settings_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `purchase_account_detail`
--
ALTER TABLE `purchase_account_detail`
  MODIFY `Purchase_trans_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `purchase_detail`
--
ALTER TABLE `purchase_detail`
  MODIFY `purchase_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `sales_account`
--
ALTER TABLE `sales_account`
  MODIFY `sales_account_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `stock id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
