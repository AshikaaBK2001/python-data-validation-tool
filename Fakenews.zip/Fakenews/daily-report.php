<?php

session_start();

require_once 'include/config.php';

if (empty($_SESSION['isLogin'])) {

    echo "<script>alert('Kindly login to proceed');location.href='index.php'</script>";
}

require_once 'include/header.php';

?>
<style>
    .container-fluid.contact_us_bg_img {
        position: relative;
    }
    .overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5); /* Adjust the opacity as needed */
        z-index: 1;
    }
    .headding {
        position: relative;
        z-index: 2;
    }
</style>
<?php
    if (empty($_GET['f_text'])) {

        $f_text = "";
    } else {

        $f_text = $_GET['f_text'];
    }

    if (isset($_GET['f_search'])) {

        if (!empty($f_text)) {


            $sql = "SELECT * from daily_sales where Date = '$f_text'";
        }
    }
   
  
?>
<div class="container-fluid contact_us_bg_img">
    <div class="overlay"></div> <!-- Semi-transparent black overlay -->
    <div class="container headding">
        <div class="row">
            <a href="home.php" class="fh5co_con_123"><i class="fa fa-home"></i></a>
            <a href="#" class="fh5co_con pt-2"> Report </a>
        </div>
    </div>
</div>
<div class="container-fluid mb-4">
    <div class="container">
        <div class="row justify-content-center align-items-center">
            <div class="col-12 text-center contact_margin_svnit">
                <div class="fh5co_heading py-2">Daily Report</div>
                <form class="form-inline">
                    <div class="form-group">
                        <input type="date" class="form-control" id="datepicker" value="<?php echo $f_text; ?>" name="f_text">
                    </div>
                    <div class="form-group ml-2">
                        <button type="submit" class="btn btn-primary" name="f_search">Search</button>
                        <a class="btn btn-danger ml-1" href="daily-report.php">Clear</a>
                        <a class="btn btn-success ml-1" href="print-daily-report.php?f_text=<?php echo $f_text; ?>">Print</a>
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <?php
            if (!empty($_GET['f_text'])) {
            ?>

            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Sales invoice number</th>
                        <th scope="col">Newspaper</th>
                        <th scope="col">Customer</th>
                        <th scope="col">Day</th>
                        <th scope="col">Weight</th>
                        <th scope="col">Price</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    
    
                    $res = mysqli_query($conn,$sql);

                    if(mysqli_num_rows($res) > 0) {
                        $i = 1;

                        while($row = mysqli_fetch_array($res)) {
                            echo "<tr>";
                            echo "<td>$i</td>";
                            echo "<td>$row[Sales_invoice_number]</td>";
                            echo "<td>$row[Newspaper_Master_id]</td>";
                            echo "<td>$row[Customer_id]</td>";
                            echo "<td>$row[Day]</td>";
                            echo "<td>$row[Weight]</td>";
                            echo "<td>$row[Price]</td>";
                            echo "<td>$row[Qty]</td>";
                            echo "<td>$row[Total]</td>";
                            echo "</tr>";
                            $i++;
                        }
                    }
                    ?>
                </tbody>
            </table>
            <?php
            }
            ?>
        </div>
    </div>
</div>



<?php

require_once 'include/footer.php';

?>